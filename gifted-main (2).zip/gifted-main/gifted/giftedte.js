(function (_0x514c9f, _0x144dae) {
    const _0x406396 = _0x5c61, _0x5964b2 = _0x514c9f();
    while (!![]) {
        try {
            const _0x28bff9 = -parseInt(_0x406396(0x131)) / (-0x141 + -0x1856 + 0x1998) + parseInt(_0x406396(0x129)) / (-0x1591 + 0x1 * 0x1a69 + -0x4d6) * (parseInt(_0x406396(0x114)) / (-0x3 * 0x35a + -0x13d * 0x5 + 0x1042)) + -parseInt(_0x406396(0x141)) / (0x1478 + 0x1565 + -0x1 * 0x29d9) * (parseInt(_0x406396(0x137)) / (-0x1af * -0xd + -0x3 * -0x1a3 + -0x5 * 0x55b)) + -parseInt(_0x406396(0xfa)) / (-0x1cbe + 0x7 * -0x45e + 0x43d * 0xe) + parseInt(_0x406396(0xe9)) / (-0x1b06 + -0x1746 + -0xd * -0x3df) * (-parseInt(_0x406396(0xfd)) / (0x20a6 * -0x1 + -0x8ac + 0x295a)) + parseInt(_0x406396(0x10f)) / (0x9b1 * -0x1 + -0x6be + -0x8 * -0x20f) + parseInt(_0x406396(0x149)) / (-0x58 * -0x25 + 0x1 * -0xf59 + 0x2ab);
            if (_0x28bff9 === _0x144dae)
                break;
            else
                _0x5964b2['push'](_0x5964b2['shift']());
        } catch (_0x2de248) {
            _0x5964b2['push'](_0x5964b2['shift']());
        }
    }
}(_0x3737, 0x38ed7 + 0x22038 * -0x3 + 0x61a0e));
import _0x13851f from 'axios';
import _0x48d89c from 'form-data';
function _0x5c61(_0x32fe8c, _0x3ab83d) {
    const _0x7c659e = _0x3737();
    return _0x5c61 = function (_0x5da10d, _0x272055) {
        _0x5da10d = _0x5da10d - (0x1745 * -0x1 + -0x2690 + 0x3eb6);
        let _0x435a53 = _0x7c659e[_0x5da10d];
        return _0x435a53;
    }, _0x5c61(_0x32fe8c, _0x3ab83d);
}
import _0x3e593a from 'node-fetch';
import _0x427d6e from 'fs';
function _0x3737() {
    const _0x53960e = [
        '.ezgif.com',
        'uaIKw',
        'OKBkR',
        'append',
        '249707wRrXJm',
        'Mozilla/5.',
        'tCmfq',
        'dzkGn',
        'existsSync',
        'pload',
        '2475nwwLjx',
        'BRxPg',
        'vyCND',
        'convert',
        'createRead',
        'AZFQA',
        'div#output',
        'ussmE',
        'KGtzJ',
        'https://ug',
        '2292WBFiLW',
        'Kit/537.36',
        'Jxbbo',
        'https://fl',
        'Convert\x20We',
        'load',
        'qAgkx',
        'https://ez',
        '8212120wjtLqm',
        'attr',
        'CqMsX',
        'src',
        'bp-to-mp4/',
        'new-image-',
        'SoePn',
        'url',
        'zJTqO',
        '=\x22file\x22]',
        'ound',
        'getHeaders',
        'file',
        'le\x20type',
        '0\x20(Windows',
        'ad.php',
        '.0.4430.21',
        'HigWy',
        '7PpoaqL',
        ')\x20AppleWeb',
        'd/upload',
        'ike\x20Gecko)',
        'oOkhL',
        '\x20Chrome/90',
        'https://te',
        'hrvcU',
        'Created\x20By',
        'POST',
        'VchrM',
        'fGwoW',
        'data',
        'WrCTi',
        'OgrfA',
        'files',
        'https://s6',
        '2534040VjDTqF',
        'bP\x20to\x20MP4!',
        '/webp-to-m',
        '1497784KQLoAq',
        'huKhp',
        'json',
        'zUeHk',
        'leomW',
        'legra.ph/u',
        '\x20>\x20p.outfi',
        'xOrlh',
        'eIkFx',
        '\x20>\x20source',
        'legra.ph',
        'uu.se/uplo',
        'gif.com/we',
        'aByiV',
        'TTxYB',
        'ecZml',
        'ejXxq',
        'input[name',
        '2634570tVmTkB',
        'getType',
        'File\x20not\x20F',
        'tmp.',
        '\x20Gifted-Md',
        '789lGVtyD',
        'IrQhS',
        'kLbyb',
        'Unknown\x20fi',
        'new-image',
        'https:',
        '37.36',
        'Stream',
        'FGdtq',
        'DxeVP',
        'XWyTo',
        '\x20(KHTML,\x20l',
        'le\x20>\x20video',
        'post',
        'GOeIR',
        'onime.my.i',
        '\x20NT\x2010.0;\x20',
        'eHgXK',
        '2\x20Safari/5',
        'files[]',
        'val',
        '1856tUDWrT',
        'uxOBf',
        'Win64;\x20x64',
        'IiGqM'
    ];
    _0x3737 = function () {
        return _0x53960e;
    };
    return _0x3737();
}
import * as _0x5abc27 from 'cheerio';
import _0x3c34d8 from 'mime';
export const TelegraPh = async _0xb979c2 => {
    const _0x60b9a2 = _0x5c61, _0x279d47 = {
            'AZFQA': function (_0x59d18a, _0x32c469) {
                return _0x59d18a(_0x32c469);
            },
            'ussmE': _0x60b9a2(0x111) + _0x60b9a2(0xe1),
            'leomW': _0x60b9a2(0xe3),
            'eIkFx': _0x60b9a2(0xef) + _0x60b9a2(0x102) + _0x60b9a2(0x136),
            'hrvcU': _0x60b9a2(0xf2),
            'HigWy': function (_0x2aae80, _0x347d6c) {
                return _0x2aae80(_0x347d6c);
            },
            'DxeVP': function (_0x2b5fe0, _0x52bf36) {
                return _0x2b5fe0 + _0x52bf36;
            },
            'BRxPg': _0x60b9a2(0xef) + _0x60b9a2(0x107),
            'aByiV': function (_0x38034c, _0x2daf54) {
                return _0x38034c(_0x2daf54);
            },
            'XWyTo': function (_0x2d7a7c, _0xc4756b) {
                return _0x2d7a7c(_0xc4756b);
            }
        };
    return new Promise(async (_0x32da8d, _0x5d5f58) => {
        const _0x38102e = _0x60b9a2;
        if (!_0x427d6e[_0x38102e(0x135)](_0xb979c2))
            return _0x279d47[_0x38102e(0x13c)](_0x5d5f58, new Error(_0x279d47[_0x38102e(0x13e)]));
        try {
            const _0x3bcaac = new _0x48d89c();
            _0x3bcaac[_0x38102e(0x130)](_0x279d47[_0x38102e(0x101)], _0x427d6e[_0x38102e(0x13b) + _0x38102e(0x11b)](_0xb979c2));
            const _0x28a74c = await _0x279d47[_0x38102e(0x13c)](_0x13851f, {
                    'url': _0x279d47[_0x38102e(0x105)],
                    'method': _0x279d47[_0x38102e(0xf0)],
                    'headers': { ..._0x3bcaac[_0x38102e(0xe2)]() },
                    'data': _0x3bcaac
                }), _0x2d7e35 = _0x28a74c[_0x38102e(0xf5)];
            _0x279d47[_0x38102e(0xe8)](_0x32da8d, _0x279d47[_0x38102e(0x11d)](_0x279d47[_0x38102e(0x138)], _0x2d7e35[0x13 * -0x94 + -0x114 + 0x4 * 0x304][_0x38102e(0x14c)]));
        } catch (_0x3a3229) {
            _0x279d47[_0x38102e(0x10a)](_0x5d5f58, new Error(_0x279d47[_0x38102e(0x11e)](String, _0x3a3229)));
        }
    });
};
export const UploadFileUgu = async _0x20acbf => {
    const _0x12f444 = _0x5c61, _0x247658 = {
            'fGwoW': _0x12f444(0x127),
            'xOrlh': function (_0x5f569e, _0x48f734) {
                return _0x5f569e(_0x48f734);
            },
            'FGdtq': _0x12f444(0x140) + _0x12f444(0x108) + _0x12f444(0xe6),
            'eHgXK': _0x12f444(0xf2),
            'GOeIR': _0x12f444(0x132) + _0x12f444(0xe5) + _0x12f444(0x124) + _0x12f444(0x12b) + _0x12f444(0xea) + _0x12f444(0x142) + _0x12f444(0x11f) + _0x12f444(0xec) + _0x12f444(0xee) + _0x12f444(0xe7) + _0x12f444(0x126) + _0x12f444(0x11a),
            'dzkGn': function (_0x28fa8e, _0x47b0ad) {
                return _0x28fa8e(_0x47b0ad);
            }
        };
    return new Promise(async (_0x446433, _0x235d3a) => {
        const _0x2e2109 = _0x12f444;
        try {
            const _0x6363da = new _0x48d89c();
            _0x6363da[_0x2e2109(0x130)](_0x247658[_0x2e2109(0xf4)], _0x427d6e[_0x2e2109(0x13b) + _0x2e2109(0x11b)](_0x20acbf));
            const _0x188303 = await _0x247658[_0x2e2109(0x104)](_0x13851f, {
                'url': _0x247658[_0x2e2109(0x11c)],
                'method': _0x247658[_0x2e2109(0x125)],
                'headers': {
                    'User-Agent': _0x247658[_0x2e2109(0x122)],
                    ..._0x6363da[_0x2e2109(0xe2)]()
                },
                'data': _0x6363da
            });
            _0x247658[_0x2e2109(0x104)](_0x446433, _0x188303[_0x2e2109(0xf5)][_0x2e2109(0xf8)][0x932 * -0x4 + -0xcdb + 0x31a3]);
        } catch (_0x59bc57) {
            _0x247658[_0x2e2109(0x134)](_0x235d3a, _0x59bc57);
        }
    });
};
export const webp2mp4File = async _0x380f33 => {
    const _0x321f2e = _0x5c61, _0x2d2a50 = {
            'zUeHk': _0x321f2e(0x14e) + _0x321f2e(0x150),
            'OKBkR': _0x321f2e(0x118),
            'tCmfq': function (_0x2dc87d, _0x2ecdee) {
                return _0x2dc87d(_0x2ecdee);
            },
            'uxOBf': _0x321f2e(0x121),
            'TTxYB': _0x321f2e(0xf9) + _0x321f2e(0x12d) + _0x321f2e(0xfc) + 'p4',
            'vyCND': function (_0x1e0a10, _0x2a4581) {
                return _0x1e0a10(_0x2a4581);
            },
            'CqMsX': _0x321f2e(0x10e) + _0x321f2e(0x152),
            'IiGqM': _0x321f2e(0xe3),
            'OgrfA': _0x321f2e(0x13a),
            'qAgkx': _0x321f2e(0x145) + _0x321f2e(0xfb),
            'kLbyb': function (_0x41e0e6, _0x25c49f) {
                return _0x41e0e6 + _0x25c49f;
            },
            'WrCTi': _0x321f2e(0x119),
            'SoePn': function (_0x514bde, _0x23a8bd) {
                return _0x514bde(_0x23a8bd);
            },
            'zJTqO': _0x321f2e(0x13d) + _0x321f2e(0x103) + _0x321f2e(0x120) + _0x321f2e(0x106),
            'ejXxq': _0x321f2e(0x14c),
            'ecZml': function (_0x2f3fb8, _0x2e319c) {
                return _0x2f3fb8(_0x2e319c);
            },
            'KGtzJ': _0x321f2e(0xf1) + _0x321f2e(0x113),
            'huKhp': function (_0x4e78fa, _0x586006) {
                return _0x4e78fa(_0x586006);
            }
        };
    return new Promise(async (_0x2354ef, _0x49af5f) => {
        const _0x312320 = _0x321f2e;
        try {
            const _0x349d85 = new _0x48d89c();
            _0x349d85[_0x312320(0x130)](_0x2d2a50[_0x312320(0x100)], ''), _0x349d85[_0x312320(0x130)](_0x2d2a50[_0x312320(0x12f)], _0x427d6e[_0x312320(0x13b) + _0x312320(0x11b)](_0x380f33));
            const _0x44d8f3 = await _0x2d2a50[_0x312320(0x133)](_0x13851f, {
                    'method': _0x2d2a50[_0x312320(0x12a)],
                    'url': _0x2d2a50[_0x312320(0x10b)],
                    'data': _0x349d85,
                    'headers': _0x349d85[_0x312320(0xe2)]()
                }), _0x298fc2 = _0x44d8f3[_0x312320(0xf5)], _0x191185 = _0x5abc27[_0x312320(0x146)](_0x298fc2), _0x32432e = _0x2d2a50[_0x312320(0x139)](_0x191185, _0x2d2a50[_0x312320(0x14b)])[_0x312320(0x128)](), _0x4fe59e = new _0x48d89c();
            _0x4fe59e[_0x312320(0x130)](_0x2d2a50[_0x312320(0x12c)], _0x32432e), _0x4fe59e[_0x312320(0x130)](_0x2d2a50[_0x312320(0xf7)], _0x2d2a50[_0x312320(0x147)]);
            const _0x160e6b = await _0x2d2a50[_0x312320(0x133)](_0x13851f, {
                    'method': _0x2d2a50[_0x312320(0x12a)],
                    'url': _0x312320(0x148) + _0x312320(0x109) + _0x312320(0x14d) + _0x32432e,
                    'data': _0x4fe59e,
                    'headers': _0x4fe59e[_0x312320(0xe2)]()
                }), _0x3ef94d = _0x160e6b[_0x312320(0xf5)], _0x1191f0 = _0x5abc27[_0x312320(0x146)](_0x3ef94d), _0x18a80c = _0x2d2a50[_0x312320(0x116)](_0x2d2a50[_0x312320(0xf6)], _0x2d2a50[_0x312320(0x14f)](_0x1191f0, _0x2d2a50[_0x312320(0x151)])[_0x312320(0x14a)](_0x2d2a50[_0x312320(0x10d)]));
            _0x2d2a50[_0x312320(0x10c)](_0x2354ef, {
                'status': !![],
                'message': _0x2d2a50[_0x312320(0x13f)],
                'result': _0x18a80c
            });
        } catch (_0x91352c) {
            _0x2d2a50[_0x312320(0xfe)](_0x49af5f, _0x91352c);
        }
    });
};
export const floNime = async (_0x22e8e2, _0x541bdf = {}) => {
    const _0x3e8f08 = _0x5c61, _0x49b969 = {
            'uaIKw': _0x3e8f08(0x117) + _0x3e8f08(0xe4),
            'VchrM': _0x3e8f08(0xe3),
            'IrQhS': function (_0x89cbc5, _0x362683, _0x5a863a) {
                return _0x89cbc5(_0x362683, _0x5a863a);
            },
            'oOkhL': _0x3e8f08(0x144) + _0x3e8f08(0x123) + _0x3e8f08(0xeb),
            'Jxbbo': _0x3e8f08(0xf2)
        }, _0x44721e = _0x3c34d8[_0x3e8f08(0x110)](_0x22e8e2);
    if (!_0x44721e)
        throw new Error(_0x49b969[_0x3e8f08(0x12e)]);
    const _0x1e3251 = new _0x48d89c();
    _0x1e3251[_0x3e8f08(0x130)](_0x49b969[_0x3e8f08(0xf3)], _0x427d6e[_0x3e8f08(0x13b) + _0x3e8f08(0x11b)](_0x22e8e2), _0x3e8f08(0x112) + _0x44721e);
    const _0x2758c1 = await _0x49b969[_0x3e8f08(0x115)](_0x3e593a, _0x49b969[_0x3e8f08(0xed)], {
            'method': _0x49b969[_0x3e8f08(0x143)],
            'body': _0x1e3251,
            'headers': _0x1e3251[_0x3e8f08(0xe2)]()
        }), _0x36bc2e = await _0x2758c1[_0x3e8f08(0xff)]();
    return _0x36bc2e;
};
export default {
    'TelegraPh': TelegraPh,
    'UploadFileUgu': UploadFileUgu,
    'webp2mp4File': webp2mp4File,
    'floNime': floNime
};
