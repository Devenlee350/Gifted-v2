function _0x5bbc(_0x5dcc42, _0x4a1bc7) {
    const _0x4f3d46 = _0x4f3d();
    return _0x5bbc = function (_0x5bbc86, _0x3eeead) {
        _0x5bbc86 = _0x5bbc86 - 0x7a;
        let _0x4ddd30 = _0x4f3d46[_0x5bbc86];
        return _0x4ddd30;
    }, _0x5bbc(_0x5dcc42, _0x4a1bc7);
}
(function (_0x3f68b1, _0x264f23) {
    const _0x2c4ca4 = _0x5bbc, _0x1d41c1 = _0x3f68b1();
    while (!![]) {
        try {
            const _0x8d045c = -parseInt(_0x2c4ca4(0x8b)) / 0x1 * (-parseInt(_0x2c4ca4(0x83)) / 0x2) + parseInt(_0x2c4ca4(0x7b)) / 0x3 + parseInt(_0x2c4ca4(0xa4)) / 0x4 + -parseInt(_0x2c4ca4(0x85)) / 0x5 + parseInt(_0x2c4ca4(0x91)) / 0x6 + -parseInt(_0x2c4ca4(0x93)) / 0x7 + -parseInt(_0x2c4ca4(0xa0)) / 0x8;
            if (_0x8d045c === _0x264f23)
                break;
            else
                _0x1d41c1['push'](_0x1d41c1['shift']());
        } catch (_0x56a9d8) {
            _0x1d41c1['push'](_0x1d41c1['shift']());
        }
    }
}(_0x4f3d, 0x95664));
function _0x4f3d() {
    const _0x1ad98a = [
        'split',
        '8382JDDvvI',
        'length',
        '1989580Hjrwke',
        'reply',
        '*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        'quick_reply',
        '\x0a*❲❒❳\x20ғᴏʀᴋs:*\x20',
        'match',
        '213LjMLLd',
        'relayMessage',
        'startsWith',
        'Message',
        'React',
        'from',
        '3930738NyXUbW',
        '\x0a*❲❒❳\x20ʟᴀsᴛ\x20ᴜᴘᴅᴀᴛᴇᴅ:*\x20',
        '8071882pQlLUK',
        'cta_url',
        'repo',
        'Header',
        'body',
        'remoteJid',
        'ᴠɪsɪᴛ,\x20ғᴏʀᴋ\x20&\x20sᴛᴀʀ\x20ʀᴇᴘᴏ',
        'ᴠɪᴇᴡ\x20ᴍᴇɴᴜ',
        'key',
        'get',
        '\x0a*❲❒❳\x20sᴛᴀʀs:*\x20',
        'Footer',
        'stringify',
        '11059808CgykRc',
        'InteractiveMessage',
        'toLocaleDateString',
        'slice',
        '3784628bmyFrw',
        'pushName',
        'includes',
        'error',
        'Error\x20processing\x20your\x20request:',
        '3154485DvdveH',
        'sʜᴏᴡ\x20💜\x20ғᴏʀ\x20ɢɪғᴛᴇᴅ',
        'toLowerCase',
        'https://github.com/mouricedevs/gifted',
        '.menu',
        'Hello\x20*_',
        'create'
    ];
    _0x4f3d = function () {
        return _0x1ad98a;
    };
    return _0x4f3d();
}
import _0x433dbd, { prepareWAMessageMedia } from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = _0x433dbd;
import _0x263fc3 from 'axios';
const handleRepoCommand = async (_0x505a2b, _0x45bbfa) => {
        const _0x2743d6 = _0x5bbc, _0x18a3c2 = 'https://api.github.com/repos/mouricedevs/gifted';
        try {
            const _0x2a32d4 = await _0x263fc3[_0x2743d6(0x9c)](_0x18a3c2), _0x26a457 = _0x2a32d4['data'], {
                    full_name: _0x323833,
                    name: _0x164e2d,
                    forks_count: _0x1cb774,
                    stargazers_count: _0x128b76,
                    created_at: _0x8189f6,
                    updated_at: _0x1854d9,
                    owner: _0x57e1ec
                } = _0x26a457, _0x6cf242 = _0x2743d6(0x80) + _0x505a2b[_0x2743d6(0xa5)] + '_,*\x0aThis\x20is\x20*Gifted-Md,*\x20A\x20Whatsapp\x20Bot\x20Built\x20by\x20*Gifted\x20Tech,*\x20Enhanced\x20with\x20Amazing\x20Features\x20to\x20Make\x20Your\x20Whatsapp\x20Communication\x20and\x20Interaction\x20Experience\x20Amazing\x0aUse\x20Below\x20Buttons\x20to\x20Navigate\x20to\x20Bot\x27s\x20Repo\x20and\x20Other\x20Areas.\x0a\x0a*❲❒❳\x20ɴᴀᴍᴇ:*\x20' + _0x164e2d + _0x2743d6(0x9d) + _0x128b76 + _0x2743d6(0x89) + _0x1cb774 + '\x0a*❲❒❳\x20ᴄʀᴇᴀᴛᴇᴅ\x20ᴏɴ:*\x20' + new Date(_0x8189f6)[_0x2743d6(0xa2)]() + _0x2743d6(0x92) + new Date(_0x1854d9)['toLocaleDateString']() + '\x0a*❲❒❳\x20ᴏᴡɴᴇʀ:*\x20𝑮𝒊𝒇𝒕𝒆𝒅\x20𝑻𝒆𝒄𝒉', _0x5a3330 = generateWAMessageFromContent(_0x505a2b[_0x2743d6(0x90)], {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto[_0x2743d6(0x8e)][_0x2743d6(0xa1)][_0x2743d6(0x81)]({
                                'body': proto[_0x2743d6(0x8e)]['InteractiveMessage']['Body'][_0x2743d6(0x81)]({ 'text': _0x6cf242 }),
                                'footer': proto[_0x2743d6(0x8e)][_0x2743d6(0xa1)][_0x2743d6(0x9e)][_0x2743d6(0x81)]({ 'text': _0x2743d6(0x87) }),
                                'header': proto[_0x2743d6(0x8e)][_0x2743d6(0xa1)][_0x2743d6(0x96)][_0x2743d6(0x81)]({
                                    ...await prepareWAMessageMedia({ 'image': { 'url': 'https://telegra.ph/file/bf3a4cac5fc11b3199b56.jpg' } }, { 'upload': _0x45bbfa['waUploadToServer'] }),
                                    'title': '',
                                    'gifPlayback': !![],
                                    'subtitle': '',
                                    'hasMediaAttachment': ![]
                                }),
                                'nativeFlowMessage': proto['Message']['InteractiveMessage']['NativeFlowMessage']['create']({
                                    'buttons': [
                                        {
                                            'name': _0x2743d6(0x88),
                                            'buttonParamsJson': JSON[_0x2743d6(0x9f)]({
                                                'display_text': _0x2743d6(0x9a),
                                                'id': _0x2743d6(0x7f)
                                            })
                                        },
                                        {
                                            'name': _0x2743d6(0x94),
                                            'buttonParamsJson': JSON['stringify']({
                                                'display_text': _0x2743d6(0x7c),
                                                'url': 'https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l'
                                            })
                                        },
                                        {
                                            'name': _0x2743d6(0x94),
                                            'buttonParamsJson': JSON[_0x2743d6(0x9f)]({
                                                'display_text': _0x2743d6(0x99),
                                                'url': _0x2743d6(0x7e)
                                            })
                                        }
                                    ]
                                }),
                                'contextInfo': {
                                    'mentionedJid': [_0x505a2b['sender']],
                                    'forwardingScore': 0x270f,
                                    'isForwarded': ![]
                                }
                            })
                        }
                    }
                }, {});
            await _0x45bbfa[_0x2743d6(0x8c)](_0x5a3330[_0x2743d6(0x9b)][_0x2743d6(0x98)], _0x5a3330['message'], { 'messageId': _0x5a3330[_0x2743d6(0x9b)]['id'] }), await _0x505a2b[_0x2743d6(0x8f)]('✅');
        } catch (_0x3d9cad) {
            console[_0x2743d6(0xa7)](_0x2743d6(0x7a), _0x3d9cad), _0x505a2b[_0x2743d6(0x86)]('Error\x20processing\x20your\x20request.'), await _0x505a2b[_0x2743d6(0x8f)]('❌');
        }
    }, searchRepo = async (_0x2e47c8, _0x180732) => {
        const _0x454375 = _0x5bbc, _0x421bda = _0x2e47c8[_0x454375(0x97)][_0x454375(0x8a)](/^[\\/!#.]/), _0x538b96 = _0x421bda ? _0x421bda[0x0] : '/', _0x17ce3b = _0x2e47c8['body'][_0x454375(0x8d)](_0x538b96) ? _0x2e47c8[_0x454375(0x97)][_0x454375(0xa3)](_0x538b96[_0x454375(0x84)])[_0x454375(0x82)]('\x20')[0x0][_0x454375(0x7d)]() : '', _0x1c444d = [
                _0x454375(0x95),
                'sc',
                'script'
            ];
        _0x1c444d[_0x454375(0xa6)](_0x17ce3b) && await handleRepoCommand(_0x2e47c8, _0x180732);
    };
export default searchRepo;
