function _0x97a0(_0x1c314a, _0x6d4511) {
    const _0x6e6acb = _0x6e6a();
    return _0x97a0 = function (_0x97a03a, _0x13a0ed) {
        _0x97a03a = _0x97a03a - 0x1e6;
        let _0x3c98d6 = _0x6e6acb[_0x97a03a];
        return _0x3c98d6;
    }, _0x97a0(_0x1c314a, _0x6d4511);
}
(function (_0xf3db6e, _0x324544) {
    const _0x57821a = _0x97a0, _0x2ce485 = _0xf3db6e();
    while (!![]) {
        try {
            const _0x58f74b = parseInt(_0x57821a(0x1f6)) / 0x1 * (-parseInt(_0x57821a(0x1ff)) / 0x2) + -parseInt(_0x57821a(0x1f1)) / 0x3 * (-parseInt(_0x57821a(0x1fb)) / 0x4) + -parseInt(_0x57821a(0x1f4)) / 0x5 * (-parseInt(_0x57821a(0x1ea)) / 0x6) + parseInt(_0x57821a(0x205)) / 0x7 + parseInt(_0x57821a(0x209)) / 0x8 * (-parseInt(_0x57821a(0x1eb)) / 0x9) + parseInt(_0x57821a(0x201)) / 0xa * (parseInt(_0x57821a(0x1f9)) / 0xb) + -parseInt(_0x57821a(0x1e6)) / 0xc * (parseInt(_0x57821a(0x20a)) / 0xd);
            if (_0x58f74b === _0x324544)
                break;
            else
                _0x2ce485['push'](_0x2ce485['shift']());
        } catch (_0x4e2971) {
            _0x2ce485['push'](_0x2ce485['shift']());
        }
    }
}(_0x6e6a, 0x557b9));
import _0x2a7e16 from 'axios';
const RandomAnime = async (_0x2960d8, _0x5f273b) => {
    const _0x5e1a65 = _0x97a0, _0x38bade = _0x2960d8['body'][_0x5e1a65(0x1ec)](/^[\\/!#.]/), _0x24eb05 = _0x38bade ? _0x38bade[0x0] : '/', _0x29352a = _0x2960d8[_0x5e1a65(0x207)][_0x5e1a65(0x204)](_0x24eb05) ? _0x2960d8['body']['slice'](_0x24eb05['length'])[_0x5e1a65(0x1fd)]('\x20')[0x0][_0x5e1a65(0x20c)]() : '', _0x22094c = [
            _0x5e1a65(0x208),
            _0x5e1a65(0x1f2),
            _0x5e1a65(0x202),
            'anime'
        ];
    if (_0x22094c[_0x5e1a65(0x1f8)](_0x29352a))
        try {
            await _0x2960d8[_0x5e1a65(0x20b)]('A\x20moment,\x20*Gifted-Md*\x20is\x20Generating\x20Your\x20Random\x20Anime\x20Search\x20Request...');
            const _0x42808e = _0x5e1a65(0x1f5), _0x5d055f = await _0x2a7e16['get'](_0x42808e), _0x40b612 = _0x5d055f['data'][_0x5e1a65(0x203)], _0x201bcf = _0x40b612[_0x5e1a65(0x1ee)], _0x424ff4 = _0x40b612['synopsis'], _0x4a6175 = _0x40b612[_0x5e1a65(0x1f3)][_0x5e1a65(0x1e9)][_0x5e1a65(0x1fa)], _0x3cc742 = _0x40b612[_0x5e1a65(0x1ef)], _0x40c115 = _0x40b612[_0x5e1a65(0x200)], _0x1791c7 = _0x5e1a65(0x1f7) + _0x201bcf + _0x5e1a65(0x1e7) + _0x3cc742 + _0x5e1a65(0x1fe) + _0x40c115 + '\x0a📝\x20Synopsis:\x20' + _0x424ff4 + '\x0a🔗\x20URL:\x20' + _0x40b612[_0x5e1a65(0x1e8)];
            _0x5f273b[_0x5e1a65(0x206)](_0x2960d8['from'], {
                'image': { 'url': _0x4a6175 },
                'caption': _0x1791c7
            }, { 'quoted': _0x2960d8 });
        } catch (_0xeb5912) {
            console[_0x5e1a65(0x1fc)]('Error\x20from\x20Gifted\x20APi:', _0xeb5912), await _0x5f273b[_0x5e1a65(0x206)](_0x2960d8[_0x5e1a65(0x1f0)], { 'text': _0x5e1a65(0x1ed) }, { 'quoted': _0x2960d8 });
        }
};
function _0x6e6a() {
    const _0x3402f2 = [
        '283261sXiVWN',
        'image_url',
        '37552luDLRA',
        'error',
        'split',
        '\x0a📡\x20Status:\x20',
        '38PldnkM',
        'status',
        '70JaITKy',
        'random-anime',
        'data',
        'startsWith',
        '2009630XPIQzi',
        'sendMessage',
        'body',
        'ranime',
        '1389616UucZUD',
        '13OsBTYA',
        'reply',
        'toLowerCase',
        '2854188OMNmEk',
        '\x0a🎬\x20Episodes:\x20',
        'url',
        'jpg',
        '50070ytbBCB',
        '9SDxGnJ',
        'match',
        'Error\x20from\x20GiftedAPi.\x20Please\x20try\x20again\x20later.',
        'title',
        'episodes',
        'from',
        '123CQVCBq',
        'randomanime',
        'images',
        '245IFSZGA',
        'https://api.jikan.moe/v4/random/anime',
        '26288XjMfVi',
        '📺\x20Tittle:\x20',
        'includes'
    ];
    _0x6e6a = function () {
        return _0x3402f2;
    };
    return _0x6e6a();
}
export default RandomAnime;
