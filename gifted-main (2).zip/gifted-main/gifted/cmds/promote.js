function _0xea7f() {
    const _0x3ea6c0 = [
        '63MKtIdQ',
        'usernames:\x20',
        'admin',
        '*🚫\x20BOT\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*',
        'catch',
        '1820229TKTzMY',
        '3254645otmtFp',
        '\x20promoted\x20successfully\x20in\x20the\x20group\x20',
        '11362mdPBme',
        'contact:\x20',
        '425724wLmFNF',
        '12468QSJkxn',
        '4660DlYAno',
        'length',
        '56VuDEdD',
        '11qojRKi',
        'log',
        'startsWith',
        'match',
        'sender',
        'from',
        'An\x20error\x20occurred\x20while\x20processing\x20the\x20command.',
        '*🚫\x20PLEASE\x20MENTION\x20OR\x20QUOTE\x20A\x20USER\x20TO\x20PROMOTE*',
        '@s.whatsapp.net',
        'decodeJid',
        'notify',
        'replace',
        'find',
        'groupMetadata',
        'trim',
        '5720EcBWbs',
        'groupParticipantsUpdate',
        'mentionedJid',
        'quoted',
        'then',
        'Failed\x20to\x20promote\x20user(s)\x20in\x20the\x20group.',
        'filter',
        'body',
        '4yMSAzm',
        'promote',
        'subject',
        'error',
        'participants',
        'toadmin',
        'getContact',
        '7479ZWlmng',
        'slice',
        'user:\x20',
        '1768890fnJYqb',
        'reply',
        'participant',
        'split',
        'toLowerCase',
        '*🚫\x20THIS\x20COMMAND\x20CAN\x20ONLY\x20BE\x20USED\x20IN\x20GROUPS*',
        'all',
        'isGroup',
        '*🚫\x20YOU\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*'
    ];
    _0xea7f = function () {
        return _0x3ea6c0;
    };
    return _0xea7f();
}
(function (_0x17aaa7, _0x17235e) {
    const _0x1e8b63 = _0x1e48, _0x3ff32f = _0x17aaa7();
    while (!![]) {
        try {
            const _0x4de4a9 = parseInt(_0x1e8b63(0x15b)) / 0x1 * (-parseInt(_0x1e8b63(0x159)) / 0x2) + -parseInt(_0x1e8b63(0x152)) / 0x3 * (parseInt(_0x1e8b63(0x13a)) / 0x4) + parseInt(_0x1e8b63(0x153)) / 0x5 + parseInt(_0x1e8b63(0x157)) / 0x6 * (parseInt(_0x1e8b63(0x14d)) / 0x7) + parseInt(_0x1e8b63(0x132)) / 0x8 * (parseInt(_0x1e8b63(0x141)) / 0x9) + -parseInt(_0x1e8b63(0x144)) / 0xa * (-parseInt(_0x1e8b63(0x15c)) / 0xb) + -parseInt(_0x1e8b63(0x158)) / 0xc * (parseInt(_0x1e8b63(0x155)) / 0xd);
            if (_0x4de4a9 === _0x17235e)
                break;
            else
                _0x3ff32f['push'](_0x3ff32f['shift']());
        } catch (_0x1bd0cb) {
            _0x3ff32f['push'](_0x3ff32f['shift']());
        }
    }
}(_0xea7f, 0x6561c));
function _0x1e48(_0x25b9e0, _0x2c8543) {
    const _0xea7f7a = _0xea7f();
    return _0x1e48 = function (_0x1e489e, _0x5166cf) {
        _0x1e489e = _0x1e489e - 0x12b;
        let _0x1ea09b = _0xea7f7a[_0x1e489e];
        return _0x1ea09b;
    }, _0x1e48(_0x25b9e0, _0x2c8543);
}
const promote = async (_0x39354a, _0x27e2d2) => {
    const _0x1e4a4a = _0x1e48;
    try {
        const _0x28ed80 = await _0x27e2d2[_0x1e4a4a(0x12c)](_0x27e2d2['user']['id']), _0x515d78 = _0x39354a[_0x1e4a4a(0x139)][_0x1e4a4a(0x15f)](/^[\\/!#.]/), _0x3346a9 = _0x515d78 ? _0x515d78[0x0] : '/', _0x2e247e = _0x39354a['body'][_0x1e4a4a(0x15e)](_0x3346a9) ? _0x39354a[_0x1e4a4a(0x139)][_0x1e4a4a(0x142)](_0x3346a9[_0x1e4a4a(0x15a)])[_0x1e4a4a(0x147)]('\x20')[0x0][_0x1e4a4a(0x148)]() : '', _0x4007be = _0x39354a[_0x1e4a4a(0x139)][_0x1e4a4a(0x142)](_0x3346a9[_0x1e4a4a(0x15a)] + _0x2e247e[_0x1e4a4a(0x15a)])[_0x1e4a4a(0x131)](), _0x2c73a8 = [
                _0x1e4a4a(0x13b),
                _0x1e4a4a(0x14f),
                _0x1e4a4a(0x13f)
            ];
        if (!_0x2c73a8['includes'](_0x2e247e))
            return;
        if (!_0x39354a[_0x1e4a4a(0x14b)])
            return _0x39354a[_0x1e4a4a(0x145)](_0x1e4a4a(0x149));
        const _0x29770f = await _0x27e2d2[_0x1e4a4a(0x130)](_0x39354a[_0x1e4a4a(0x161)]), _0x2530a4 = _0x29770f[_0x1e4a4a(0x13e)], _0x2d8c48 = _0x2530a4[_0x1e4a4a(0x12f)](_0x5b9b9f => _0x5b9b9f['id'] === _0x28ed80)?.[_0x1e4a4a(0x14f)], _0x5d913e = _0x2530a4['find'](_0x34178d => _0x34178d['id'] === _0x39354a[_0x1e4a4a(0x160)])?.[_0x1e4a4a(0x14f)];
        if (!_0x2d8c48)
            return _0x39354a[_0x1e4a4a(0x145)](_0x1e4a4a(0x150));
        if (!_0x5d913e)
            return _0x39354a[_0x1e4a4a(0x145)](_0x1e4a4a(0x14c));
        if (!_0x39354a['mentionedJid'])
            _0x39354a[_0x1e4a4a(0x134)] = [];
        if (_0x39354a['quoted']?.[_0x1e4a4a(0x146)])
            _0x39354a[_0x1e4a4a(0x134)]['push'](_0x39354a[_0x1e4a4a(0x135)][_0x1e4a4a(0x146)]);
        const _0x4690b8 = _0x39354a[_0x1e4a4a(0x134)][_0x1e4a4a(0x15a)] > 0x0 ? _0x39354a[_0x1e4a4a(0x134)] : _0x4007be[_0x1e4a4a(0x12e)](/[^0-9]/g, '')['length'] > 0x0 ? [_0x4007be[_0x1e4a4a(0x12e)](/[^0-9]/g, '') + _0x1e4a4a(0x12b)] : [];
        if (_0x4690b8['length'] === 0x0)
            return _0x39354a['reply'](_0x1e4a4a(0x163));
        console[_0x1e4a4a(0x15d)]('users:\x20', _0x4690b8);
        const _0x259f28 = _0x4690b8[_0x1e4a4a(0x138)](Boolean), _0x26e31e = await Promise[_0x1e4a4a(0x14a)](_0x259f28['map'](async _0x3911e2 => {
                const _0x371db3 = _0x1e4a4a;
                console['log'](_0x371db3(0x143), _0x3911e2);
                try {
                    const _0x523543 = await _0x27e2d2[_0x371db3(0x140)](_0x3911e2);
                    return console[_0x371db3(0x15d)](_0x371db3(0x156), _0x523543), _0x523543[_0x371db3(0x12d)] || _0x523543['pushname'] || _0x3911e2['split']('@')[0x0];
                } catch (_0x54a9fa) {
                    return _0x3911e2[_0x371db3(0x147)]('@')[0x0];
                }
            }));
        console[_0x1e4a4a(0x15d)](_0x1e4a4a(0x14e), _0x26e31e), await _0x27e2d2[_0x1e4a4a(0x133)](_0x39354a[_0x1e4a4a(0x161)], _0x259f28, _0x1e4a4a(0x13b))[_0x1e4a4a(0x136)](() => {
            const _0x3cd33e = _0x1e4a4a, _0x5ac2a1 = _0x26e31e['map'](_0x42e5a9 => '@' + _0x42e5a9)['join'](',\x20');
            _0x39354a[_0x3cd33e(0x145)]('*Users\x20' + _0x5ac2a1 + _0x3cd33e(0x154) + _0x29770f[_0x3cd33e(0x13c)] + '.*');
        })[_0x1e4a4a(0x151)](() => _0x39354a[_0x1e4a4a(0x145)](_0x1e4a4a(0x137)));
    } catch (_0x347969) {
        console[_0x1e4a4a(0x13d)]('Error:', _0x347969), _0x39354a[_0x1e4a4a(0x145)](_0x1e4a4a(0x162));
    }
};
export default promote;
