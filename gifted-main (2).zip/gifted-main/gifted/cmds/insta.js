(function (_0x58ed44, _0x58e86a) {
    const _0x197b9b = _0x1d5b, _0x485f24 = _0x58ed44();
    while (!![]) {
        try {
            const _0x101154 = parseInt(_0x197b9b(0x156)) / 0x1 * (-parseInt(_0x197b9b(0x161)) / 0x2) + parseInt(_0x197b9b(0x163)) / 0x3 * (-parseInt(_0x197b9b(0x169)) / 0x4) + -parseInt(_0x197b9b(0x17e)) / 0x5 * (-parseInt(_0x197b9b(0x166)) / 0x6) + parseInt(_0x197b9b(0x17c)) / 0x7 * (-parseInt(_0x197b9b(0x171)) / 0x8) + -parseInt(_0x197b9b(0x179)) / 0x9 + -parseInt(_0x197b9b(0x154)) / 0xa * (parseInt(_0x197b9b(0x15b)) / 0xb) + parseInt(_0x197b9b(0x162)) / 0xc;
            if (_0x101154 === _0x58e86a)
                break;
            else
                _0x485f24['push'](_0x485f24['shift']());
        } catch (_0x1239b0) {
            _0x485f24['push'](_0x485f24['shift']());
        }
    }
}(_0x1bb4, 0xe5efb));
function _0x1d5b(_0xa965c6, _0x32cc8f) {
    const _0x1bb48f = _0x1bb4();
    return _0x1d5b = function (_0x1d5b11, _0x5e24a4) {
        _0x1d5b11 = _0x1d5b11 - 0x153;
        let _0xe67837 = _0x1bb48f[_0x1d5b11];
        return _0xe67837;
    }, _0x1d5b(_0xa965c6, _0x32cc8f);
}
import _0x2c3a17 from 'node-fetch';
function _0x1bb4() {
    const _0x47fb17 = [
        'length',
        '88cjPizS',
        'insta',
        'from',
        '&apikey=',
        'reply',
        'gifteddevskk',
        'instagram',
        'Hello\x20_*',
        '15198822wJYLlL',
        'success',
        'video/mp4',
        '21343HMQzWp',
        'https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l',
        '125dwYRxO',
        'split',
        '2960FJnEWk',
        'Powered\x20by\x20Gifted\x20Tech',
        '28193mcdJND',
        'Failed\x20to\x20download\x20video.\x20Please\x20try\x20again\x20later.',
        'instadl',
        'toLowerCase',
        'Failed\x20with\x20error\x20from\x20Gifted\x20API.\x20Please\x20try\x20again\x20later.',
        '8371BdODfA',
        '*_\x20,\x0aPlease\x20provide\x20instagram\x20video\x20URL,\x20\x0aEg\x20*.insta\x20_your_url_',
        'startsWith',
        'https://api.giftedtechnexus.co.ke',
        '/api/download/instadlv3?url=',
        'https://telegra.ph/file/c2a4d8d65722553da4c89.jpg',
        '94styHJw',
        '36305196bTWoBy',
        '18ZbrEfy',
        'slice',
        'Error\x20from\x20Gifted\x20API:',
        '315480dlNrhM',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        'trim',
        '83660twGULZ',
        'includes',
        'status',
        'body',
        'error',
        'A\x20moment,\x20*Gifted-Md*\x20is\x20Processing\x20from\x20GiftedAPi...',
        'sendMessage'
    ];
    _0x1bb4 = function () {
        return _0x47fb17;
    };
    return _0x1bb4();
}
const InstaDl = async (_0x2196d1, _0x1a74d5) => {
    const _0x34d48c = _0x1d5b, _0x25fe31 = _0x2196d1[_0x34d48c(0x16c)]['match'](/^[\\/!#.]/), _0x276aea = _0x25fe31 ? _0x25fe31[0x0] : '/', _0x1f7064 = _0x34d48c(0x15e), _0xd87993 = _0x34d48c(0x176), _0x5ddf16 = _0x2196d1[_0x34d48c(0x16c)][_0x34d48c(0x15d)](_0x276aea) ? _0x2196d1[_0x34d48c(0x16c)][_0x34d48c(0x164)](_0x276aea[_0x34d48c(0x170)])[_0x34d48c(0x153)]('\x20')[0x0][_0x34d48c(0x159)]() : '', _0x4e4659 = _0x2196d1[_0x34d48c(0x16c)][_0x34d48c(0x164)](_0x276aea[_0x34d48c(0x170)] + _0x5ddf16[_0x34d48c(0x170)])[_0x34d48c(0x168)](), _0x19fca3 = [
            _0x34d48c(0x172),
            'ig',
            'igdl',
            _0x34d48c(0x158),
            _0x34d48c(0x177)
        ];
    if (_0x19fca3[_0x34d48c(0x16a)](_0x5ddf16)) {
        if (!_0x4e4659) {
            await _0x2196d1['reply'](_0x34d48c(0x178) + _0x2196d1['pushName'] + _0x34d48c(0x15c));
            return;
        }
        try {
            await _0x2196d1['React']('🕘'), await _0x2196d1[_0x34d48c(0x175)](_0x34d48c(0x16e));
            const _0x1a5dcd = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/, _0xe7696a = _0x1a5dcd['test'](_0x4e4659), _0x3bd51d = await _0x2c3a17(_0x1f7064 + _0x34d48c(0x15f) + encodeURIComponent(_0x4e4659) + _0x34d48c(0x174) + _0xd87993), _0x2267c4 = await _0x3bd51d['json']();
            if (_0x2267c4[_0x34d48c(0x16b)] === 0xc8 && _0x2267c4[_0x34d48c(0x17a)]) {
                const _0x27dd80 = _0x2267c4['result'][0x0]['url'];
                await _0x1a74d5[_0x34d48c(0x16f)](_0x2196d1[_0x34d48c(0x173)], {
                    'video': { 'url': _0x27dd80 },
                    'mimetype': _0x34d48c(0x17b),
                    'caption': _0x34d48c(0x167),
                    'contextInfo': {
                        'externalAdReply': {
                            'showAdAttribution': ![],
                            'body': _0x34d48c(0x155),
                            'thumbnailUrl': _0x34d48c(0x160),
                            'sourceUrl': _0x34d48c(0x17d),
                            'mediaType': 0x1,
                            'renderLargerThumbnail': ![]
                        }
                    }
                }, { 'quoted': _0x2196d1 }), await _0x2196d1['React']('✅');
            } else
                await _0x2196d1[_0x34d48c(0x175)](_0x34d48c(0x157));
        } catch (_0x1dcc91) {
            console[_0x34d48c(0x16d)](_0x34d48c(0x165), _0x1dcc91), await _0x1a74d5[_0x34d48c(0x16f)](_0x2196d1[_0x34d48c(0x173)], { 'text': _0x34d48c(0x15a) });
        }
    }
};
export default InstaDl;
