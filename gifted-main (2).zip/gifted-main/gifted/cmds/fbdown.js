function _0x6f97(_0x2d1949, _0x40725a) {
    const _0xacf919 = _0xacf9();
    return _0x6f97 = function (_0x6f972b, _0x27f86b) {
        _0x6f972b = _0x6f972b - 0x199;
        let _0x3facb4 = _0xacf919[_0x6f972b];
        return _0x3facb4;
    }, _0x6f97(_0x2d1949, _0x40725a);
}
(function (_0x109be8, _0x4e76e3) {
    const _0x2ecfd4 = _0x6f97, _0x1734e2 = _0x109be8();
    while (!![]) {
        try {
            const _0x247bee = parseInt(_0x2ecfd4(0x1b8)) / 0x1 * (-parseInt(_0x2ecfd4(0x1c1)) / 0x2) + -parseInt(_0x2ecfd4(0x1d1)) / 0x3 + parseInt(_0x2ecfd4(0x1c3)) / 0x4 * (parseInt(_0x2ecfd4(0x1c2)) / 0x5) + parseInt(_0x2ecfd4(0x1aa)) / 0x6 * (-parseInt(_0x2ecfd4(0x1d6)) / 0x7) + parseInt(_0x2ecfd4(0x199)) / 0x8 + parseInt(_0x2ecfd4(0x19b)) / 0x9 * (-parseInt(_0x2ecfd4(0x1a8)) / 0xa) + parseInt(_0x2ecfd4(0x1d5)) / 0xb;
            if (_0x247bee === _0x4e76e3)
                break;
            else
                _0x1734e2['push'](_0x1734e2['shift']());
        } catch (_0x437b9c) {
            _0x1734e2['push'](_0x1734e2['shift']());
        }
    }
}(_0xacf9, 0x32e47));
import _0x303f2a, { prepareWAMessageMedia } from 'gifted-baileys';
function _0xacf9() {
    const _0x32a17e = [
        'sendMessage',
        'facebook',
        'arrayBuffer',
        'Error\x20processing\x20your\x20request:',
        '587460mRHqbP',
        'Please\x20provide\x20a\x20Facebook\x20video\x20URL.',
        '113232qwMSpR',
        '\x0a*Size*:\x20',
        'quick_reply',
        'interactiveResponseMessage',
        'toFixed',
        'video/mp4',
        'reply',
        'https://telegra.ph/file/bf3a4cac5fc11b3199b56.jpg',
        '\x20|\x20Size:\x20',
        'map',
        'Error\x20processing\x20your\x20request.',
        'status',
        'waUploadToServer',
        'InteractiveMessage',
        '121966PBJCwD',
        'toLowerCase',
        'match',
        'split',
        'key',
        'message',
        'body',
        'fbdl',
        'from',
        '2DJkGTO',
        '109635iVZmOx',
        '20RXRKjt',
        'parse',
        'create',
        '*𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐅𝐁\x20𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑*\x0a\x0a*Tittle*:\x20',
        'startsWith',
        'No\x20results\x20found.',
        'remoteJid',
        'resolution',
        'Video\x20Qualities',
        'slice',
        'Body',
        'set',
        'templateButtonReplyMessage',
        'get',
        '602025fTDIFh',
        'stringify',
        'length',
        'React',
        '10434721EZNwZR',
        '49YjVYXp',
        '129408zocmyi',
        'data',
        '63JTSVSz',
        'nativeFlowResponseMessage',
        'media_',
        'Message',
        'sender',
        'trim',
        'Header',
        '📥\x20ᴅᴏᴡɴʟᴏᴀᴅ\x20',
        'Footer'
    ];
    _0xacf9 = function () {
        return _0x32a17e;
    };
    return _0xacf9();
}
const {generateWAMessageFromContent, proto} = _0x303f2a;
import _0x37df3d from 'nayan-media-downloader';
const {ndown} = _0x37df3d, fbSearchResultsMap = new Map();
let fbSearchIndex = 0x1;
const facebookCommand = async (_0xdeeda5, _0x3175e5) => {
        const _0x141227 = _0x6f97;
        let _0x35b9e5;
        const _0x10bc00 = _0xdeeda5?.[_0x141227(0x1bd)]?.[_0x141227(0x1cf)]?.['selectedId'], _0x4e2f22 = _0xdeeda5?.[_0x141227(0x1bd)]?.[_0x141227(0x1ad)];
        if (_0x4e2f22) {
            const _0x91abb8 = _0x4e2f22[_0x141227(0x19c)]?.['paramsJson'];
            if (_0x91abb8) {
                const _0x461e1d = JSON[_0x141227(0x1c4)](_0x91abb8);
                _0x35b9e5 = _0x461e1d['id'];
            }
        }
        const _0x55cac7 = _0x35b9e5 || _0x10bc00, _0x5817e9 = _0xdeeda5[_0x141227(0x1be)][_0x141227(0x1ba)](/^[\\/!#.]/), _0x26647d = _0x5817e9 ? _0x5817e9[0x0] : '/', _0x1ac46b = _0xdeeda5[_0x141227(0x1be)][_0x141227(0x1c7)](_0x26647d) ? _0xdeeda5[_0x141227(0x1be)]['slice'](_0x26647d[_0x141227(0x1d3)])[_0x141227(0x1bb)]('\x20')[0x0][_0x141227(0x1b9)]() : '', _0x32bada = _0xdeeda5[_0x141227(0x1be)][_0x141227(0x1cc)](_0x26647d['length'] + _0x1ac46b[_0x141227(0x1d3)])[_0x141227(0x1a0)](), _0x190b40 = [
                _0x141227(0x1a5),
                'fb',
                _0x141227(0x1bf)
            ];
        if (_0x190b40['includes'](_0x1ac46b)) {
            if (!_0x32bada)
                return _0xdeeda5[_0x141227(0x1b0)](_0x141227(0x1a9));
            try {
                await _0xdeeda5[_0x141227(0x1d4)]('🕘'), await _0xdeeda5[_0x141227(0x1b0)]('A\x20Moment,*Gifted-Md*\x20is\x20Generating\x20Download\x20Buttons,\x20Please\x20Wait...');
                const _0x2feda4 = await ndown(_0x32bada);
                if (!_0x2feda4[_0x141227(0x1b5)]) {
                    await _0xdeeda5[_0x141227(0x1b0)](_0x141227(0x1c8)), await _0xdeeda5['React']('❌');
                    return;
                }
                fbSearchResultsMap[_0x141227(0x1ce)](fbSearchIndex, _0x2feda4);
                const _0x517e5a = _0x2feda4['data'][_0x141227(0x1b3)]((_0x3ee18d, _0x4d4e47) => ({
                        'name': _0x141227(0x1ac),
                        'buttonParamsJson': JSON[_0x141227(0x1d2)]({
                            'display_text': _0x141227(0x1a2) + _0x3ee18d[_0x141227(0x1ca)],
                            'id': _0x141227(0x19d) + _0x4d4e47 + '_' + fbSearchIndex
                        })
                    })), _0x2543f1 = _0x2feda4[_0x141227(0x19a)]['map'](_0x409cd5 => ({
                        'title': _0x141227(0x1cb),
                        'rows': [{
                                'title': '📥\x20ᴅᴏᴡɴʟᴏᴀᴅ\x20' + _0x409cd5[_0x141227(0x1ca)],
                                'description': 'Resolution:\x20' + _0x409cd5[_0x141227(0x1ca)] + _0x141227(0x1b2) + (_0x409cd5['size'] / (0x400 * 0x400))[_0x141227(0x1ae)](0x2) + '\x20MB',
                                'id': 'media_' + fbSearchIndex + '_' + _0x409cd5[_0x141227(0x1ca)]
                            }]
                    })), _0x137193 = generateWAMessageFromContent(_0xdeeda5[_0x141227(0x1c0)], {
                        'viewOnceMessage': {
                            'message': {
                                'messageContextInfo': {
                                    'deviceListMetadata': {},
                                    'deviceListMetadataVersion': 0x2
                                },
                                'interactiveMessage': proto[_0x141227(0x19e)][_0x141227(0x1b7)]['create']({
                                    'body': proto[_0x141227(0x19e)][_0x141227(0x1b7)][_0x141227(0x1cd)][_0x141227(0x1c5)]({ 'text': _0x141227(0x1c6) + _0x2feda4['title'] + _0x141227(0x1ab) + (_0x2feda4['size'] / (0x400 * 0x400))[_0x141227(0x1ae)](0x2) + '\x20MB' }),
                                    'footer': proto[_0x141227(0x19e)][_0x141227(0x1b7)][_0x141227(0x1a3)]['create']({ 'text': '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*' }),
                                    'header': proto['Message']['InteractiveMessage'][_0x141227(0x1a1)][_0x141227(0x1c5)]({
                                        ...await prepareWAMessageMedia({ 'image': { 'url': _0x141227(0x1b1) } }, { 'upload': _0x3175e5[_0x141227(0x1b6)] }),
                                        'title': '',
                                        'gifPlayback': !![],
                                        'subtitle': '',
                                        'hasMediaAttachment': ![]
                                    }),
                                    'nativeFlowMessage': proto[_0x141227(0x19e)][_0x141227(0x1b7)]['NativeFlowMessage'][_0x141227(0x1c5)]({ 'buttons': _0x517e5a }),
                                    'contextInfo': {
                                        'mentionedJid': [_0xdeeda5[_0x141227(0x19f)]],
                                        'forwardingScore': 0x270f,
                                        'isForwarded': ![]
                                    }
                                })
                            }
                        }
                    }, {});
                await _0x3175e5['relayMessage'](_0x137193[_0x141227(0x1bc)][_0x141227(0x1c9)], _0x137193[_0x141227(0x1bd)], { 'messageId': _0x137193[_0x141227(0x1bc)]['id'] }), await _0xdeeda5[_0x141227(0x1d4)]('✅'), await _0xdeeda5[_0x141227(0x1b0)]('Success...'), fbSearchIndex += 0x1;
            } catch (_0x3c28e6) {
                console['error'](_0x141227(0x1a7), _0x3c28e6), await _0xdeeda5[_0x141227(0x1b0)](_0x141227(0x1b4)), await _0xdeeda5[_0x141227(0x1d4)]('❌');
            }
        } else {
            if (_0x55cac7) {
                if (_0x55cac7[_0x141227(0x1c7)](_0x141227(0x19d))) {
                    const _0x51c507 = _0x55cac7[_0x141227(0x1bb)]('_'), _0x49ed3b = parseInt(_0x51c507[0x1]), _0x3d1e8c = parseInt(_0x51c507[0x2]), _0x513c5e = fbSearchResultsMap[_0x141227(0x1d0)](_0x3d1e8c);
                    if (_0x513c5e)
                        try {
                            const _0x516e6c = _0x513c5e[_0x141227(0x19a)][_0x49ed3b]['url'];
                            let _0x50cd58, _0x433a9c, _0x47fb83;
                            _0x50cd58 = await getStreamBuffer(_0x516e6c), _0x433a9c = 'video/mp4';
                            const _0x3aba90 = _0x50cd58[_0x141227(0x1d3)] / (0x400 * 0x400);
                            _0x3aba90 <= 0x12c ? (_0x47fb83 = {
                                'video': _0x50cd58,
                                'mimetype': _0x141227(0x1af),
                                'caption': '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*'
                            }, await _0x3175e5[_0x141227(0x1a4)](_0xdeeda5[_0x141227(0x1c0)], _0x47fb83, { 'quoted': _0xdeeda5 })) : await _0xdeeda5[_0x141227(0x1b0)]('The\x20video\x20file\x20size\x20exceeds\x20300MB.');
                        } catch (_0x5a12e5) {
                            console['error']('Error\x20processing\x20your\x20request:', _0x5a12e5), await _0xdeeda5['reply']('Error\x20processing\x20your\x20request.'), await _0xdeeda5['React']('❌');
                        }
                }
            }
        }
    }, getStreamBuffer = async _0x575ea4 => {
        const _0x2bd839 = _0x6f97, _0x1aee37 = await fetch(_0x575ea4), _0x5aa733 = await _0x1aee37[_0x2bd839(0x1a6)]();
        return Buffer['from'](_0x5aa733);
    };
export default facebookCommand;
