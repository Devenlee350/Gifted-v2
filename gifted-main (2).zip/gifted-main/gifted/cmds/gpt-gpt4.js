(function (_0x1a67db, _0x5a3428) {
    const _0x34fae5 = _0x15f4, _0x2ae7c7 = _0x1a67db();
    while (!![]) {
        try {
            const _0x20c9b0 = parseInt(_0x34fae5(0x144)) / (-0x26de + -0x12d5 * 0x1 + 0x39b4) + parseInt(_0x34fae5(0x14f)) / (0x2 * -0xd29 + -0x1bd + 0x1c11 * 0x1) + -parseInt(_0x34fae5(0x171)) / (-0xe29 + 0x1325 * -0x1 + -0xb1b * -0x3) + -parseInt(_0x34fae5(0x17d)) / (-0x32 + 0x1ddf + 0x9e3 * -0x3) + -parseInt(_0x34fae5(0x176)) / (-0x173a * -0x1 + 0x218a * -0x1 + -0xa55 * -0x1) + -parseInt(_0x34fae5(0x126)) / (0x1c2 * -0x13 + -0xa26 + -0x3f6 * -0xb) * (-parseInt(_0x34fae5(0x10c)) / (-0x16f8 + 0x141 + -0x15be * -0x1)) + parseInt(_0x34fae5(0x14d)) / (-0x1b20 + -0x219d + 0x3cc5) * (parseInt(_0x34fae5(0x14e)) / (-0xb74 + 0x1 * -0x5fd + -0x117a * -0x1));
            if (_0x20c9b0 === _0x5a3428)
                break;
            else
                _0x2ae7c7['push'](_0x2ae7c7['shift']());
        } catch (_0x2071f9) {
            _0x2ae7c7['push'](_0x2ae7c7['shift']());
        }
    }
}(_0xf7a8, -0x6ec8 + -0x46478 + 0xf7c6 * 0x9));
import { GiftedGpt } from 'gifted-gpt';
const gpt4 = new GiftedGpt();
function _0xf7a8() {
    const _0x392c82 = [
        'NativeFlow',
        '\x20ɢɪғᴛᴇᴅ',
        'React',
        'relayMessa',
        'gpt4ai',
        'YzcCH',
        'message',
        '𝟓*',
        'mands.\x20You',
        '371xlsuHL',
        'system',
        '*Gifted-Md',
        'PhInm',
        'providers',
        'VlWzw',
        'Body',
        'includes',
        'sʜᴏᴡ\x20💜\x20ғᴏʀ',
        'Header',
        'chatgpt4',
        'cta_url',
        'dCBuT',
        'est...',
        'pt4.\x0a\x20Plea',
        '📋\x20ᴄᴏᴘʏ\x20ᴡʜᴏ',
        'FPJba',
        'stringify',
        'gjMtJ',
        'oZjgh',
        'XMzuv',
        'XJhvq',
        'SJZBk',
        'Interactiv',
        '_,*\x0a\x20I\x20am\x20',
        'lEkek',
        '24414eVKPAA',
        'match',
        'gpt-4',
        'ccepts\x20com',
        'DVWZm',
        'tesy\x20of\x20Bi',
        'ISTkHTj4xv',
        'crosoft.',
        'create',
        'sponse:',
        'reply',
        'ʟᴇ\x20ᴛᴇxᴛ',
        'quick_repl',
        'text\x20and\x20a',
        'ng\x20from\x20Mi',
        'atsapp.com',
        'hat\x20proces',
        'Footer',
        'error',
        'ifted-Md\x20t',
        'DVIlQ',
        'uTIMz',
        'body',
        '.menu',
        'mium\x20ChatG',
        'gpt',
        'Gifted\x20Pre',
        '/channel/0',
        'uestion.',
        'You\x27re\x20a\x20W',
        '220582BGfGjX',
        'gpt4',
        'from',
        'RdgcG',
        'pushName',
        'ShGmK',
        'A\x20moment,\x20',
        '\x20GPT4\x20Requ',
        't\x20called\x20G',
        '8LybeVq',
        '4397427OCQUwa',
        '94180nSBSLq',
        '𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕',
        'chatgpt',
        'hatsApp\x20bo',
        'CjKty',
        '029VaYauR9',
        '*\x20is\x20Gener',
        'tion',
        'ating\x20Your',
        'https://wh',
        'se\x20Ask\x20a\x20Q',
        'Message',
        'remoteJid',
        'GPT',
        'chatComple',
        'rpgyc',
        'ᴍᴀɪɴ\x20ᴍᴇɴᴜ',
        'jltYv',
        'qXqAM',
        'PaOem',
        'trim',
        'ing\x20GPT\x20re',
        'cta_copy',
        'ing\x20respon',
        'Error\x20gett',
        'key',
        'ᴇʀᴀᴛᴇᴅ\x20ᴄᴏᴅ',
        'user',
        'Hello\x20*_',
        'length',
        'tNHHX',
        'eMessage',
        'toLowerCas',
        '📋\x20ᴄᴏᴘʏ\x20ɢᴇɴ',
        '1159677wVAVaI',
        'ses\x20users\x20',
        'split',
        'copy_code',
        'slice',
        '618035fgcSsR',
        'pSUiY',
        '\x20work\x20cour',
        'i1l',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆',
        'push',
        'startsWith',
        '828480AgyluU',
        'NmXHq',
        'se\x20from\x20GP'
    ];
    _0xf7a8 = function () {
        return _0x392c82;
    };
    return _0xf7a8();
}
import _0x250301, { prepareWAMessageMedia } from 'gifted-baileys';
function _0x15f4(_0x8ea4fc, _0x2e52bb) {
    const _0x1e331f = _0xf7a8();
    return _0x15f4 = function (_0x4d7022, _0x272785) {
        _0x4d7022 = _0x4d7022 - (0x1482 + 0x992 + -0xe87 * 0x2);
        let _0x3720de = _0x1e331f[_0x4d7022];
        return _0x3720de;
    }, _0x15f4(_0x8ea4fc, _0x2e52bb);
}
const {generateWAMessageFromContent, proto} = _0x250301, gptResponse = async (_0x335120, _0x3739f0) => {
        const _0x4e1323 = _0x15f4, _0x22833c = {
                'PaOem': function (_0xb2eb8a, _0x198322) {
                    return _0xb2eb8a + _0x198322;
                },
                'CjKty': _0x4e1323(0x116),
                'tNHHX': _0x4e1323(0x13f),
                'PhInm': _0x4e1323(0x151),
                'VlWzw': _0x4e1323(0x145),
                'NmXHq': _0x4e1323(0x107),
                'uTIMz': _0x4e1323(0x14a) + _0x4e1323(0x10e) + _0x4e1323(0x155) + _0x4e1323(0x157) + _0x4e1323(0x14b) + _0x4e1323(0x119),
                'gjMtJ': _0x4e1323(0x10d),
                'XMzuv': _0x4e1323(0x143) + _0x4e1323(0x152) + _0x4e1323(0x14c) + _0x4e1323(0x139) + _0x4e1323(0x136) + _0x4e1323(0x172) + _0x4e1323(0x133) + _0x4e1323(0x129) + _0x4e1323(0x10b) + _0x4e1323(0x178) + _0x4e1323(0x12b) + _0x4e1323(0x134) + _0x4e1323(0x12d),
                'YzcCH': _0x4e1323(0x16a),
                'jltYv': _0x4e1323(0x128),
                'FPJba': _0x4e1323(0x165),
                'oZjgh': _0x4e1323(0x170) + _0x4e1323(0x169) + 'ᴇ',
                'qXqAM': _0x4e1323(0x174),
                'dCBuT': _0x4e1323(0x11b) + _0x4e1323(0x131),
                'DVWZm': _0x4e1323(0x117),
                'SJZBk': _0x4e1323(0x114) + _0x4e1323(0x181),
                'DVIlQ': _0x4e1323(0x132) + 'y',
                'lEkek': _0x4e1323(0x15f),
                'rpgyc': _0x4e1323(0x13d),
                'pSUiY': function (_0x4a4dd5, _0x40fab9, _0x3bbdc2, _0x511b64) {
                    return _0x4a4dd5(_0x40fab9, _0x3bbdc2, _0x511b64);
                },
                'XJhvq': _0x4e1323(0x17a) + _0x4e1323(0x150) + _0x4e1323(0x10a),
                'ShGmK': _0x4e1323(0x167) + _0x4e1323(0x164) + _0x4e1323(0x12f),
                'RdgcG': _0x4e1323(0x167) + _0x4e1323(0x166) + _0x4e1323(0x17f) + 'T.'
            }, _0x13cfc2 = _0x335120[_0x4e1323(0x13c)][_0x4e1323(0x127)](/^[\\/!#.]/), _0x2445e9 = _0x13cfc2 ? _0x13cfc2[0x23e2 + -0xd97 + -0xd * 0x1b7] : '/', _0x44f470 = _0x335120[_0x4e1323(0x13c)][_0x4e1323(0x17c)](_0x2445e9) ? _0x335120[_0x4e1323(0x13c)][_0x4e1323(0x175)](_0x2445e9[_0x4e1323(0x16c)])[_0x4e1323(0x173)]('\x20')[-0x3f6 * 0x1 + 0x192 * -0x15 + 0x24f0][_0x4e1323(0x16f) + 'e']() : '', _0x1fe06d = _0x335120[_0x4e1323(0x13c)][_0x4e1323(0x175)](_0x22833c[_0x4e1323(0x162)](_0x2445e9[_0x4e1323(0x16c)], _0x44f470[_0x4e1323(0x16c)]))[_0x4e1323(0x163)](), _0xa64866 = [
                _0x22833c[_0x4e1323(0x153)],
                _0x22833c[_0x4e1323(0x16d)],
                _0x22833c[_0x4e1323(0x10f)],
                _0x22833c[_0x4e1323(0x111)],
                _0x22833c[_0x4e1323(0x17e)]
            ];
        if (_0xa64866[_0x4e1323(0x113)](_0x44f470)) {
            if (!_0x1fe06d)
                return _0x335120[_0x4e1323(0x130)](_0x4e1323(0x16b) + _0x335120[_0x4e1323(0x148)] + (_0x4e1323(0x124) + _0x4e1323(0x140) + _0x4e1323(0x13e) + _0x4e1323(0x11a) + _0x4e1323(0x159) + _0x4e1323(0x142)));
            try {
                await _0x335120[_0x4e1323(0x182)]('🕘'), await _0x335120[_0x4e1323(0x130)](_0x22833c[_0x4e1323(0x13b)]);
                const _0x51de4c = [
                        {
                            'role': _0x22833c[_0x4e1323(0x11e)],
                            'content': _0x22833c[_0x4e1323(0x120)]
                        },
                        {
                            'role': _0x22833c[_0x4e1323(0x108)],
                            'content': _0x1fe06d
                        }
                    ], _0x4ca3e3 = {
                        'provider': gpt4[_0x4e1323(0x110)][_0x4e1323(0x15c)],
                        'model': _0x22833c[_0x4e1323(0x160)],
                        'debug': !![],
                        'proxy': ''
                    }, _0x4e532d = await gpt4[_0x4e1323(0x15d) + _0x4e1323(0x156)](_0x51de4c, _0x4ca3e3), _0x23a58f = _0x4e532d, _0x3bb024 = _0x23a58f[_0x4e1323(0x127)](/```([\s\S]*?)```/);
                let _0x3da489 = [];
                if (_0x3bb024) {
                    const _0x1e6dc0 = _0x3bb024[-0xf0 + 0xf35 + -0xa6 * 0x16];
                    _0x3da489[_0x4e1323(0x17b)]({
                        'name': _0x22833c[_0x4e1323(0x11c)],
                        'buttonParamsJson': JSON[_0x4e1323(0x11d)]({
                            'display_text': _0x22833c[_0x4e1323(0x11f)],
                            'id': _0x22833c[_0x4e1323(0x161)],
                            'copy_code': _0x1e6dc0
                        })
                    });
                }
                _0x3da489[_0x4e1323(0x17b)]({
                    'name': _0x22833c[_0x4e1323(0x11c)],
                    'buttonParamsJson': JSON[_0x4e1323(0x11d)]({
                        'display_text': _0x22833c[_0x4e1323(0x118)],
                        'id': _0x22833c[_0x4e1323(0x161)],
                        'copy_code': _0x23a58f
                    })
                }, {
                    'name': _0x22833c[_0x4e1323(0x12a)],
                    'buttonParamsJson': JSON[_0x4e1323(0x11d)]({
                        'display_text': _0x22833c[_0x4e1323(0x122)],
                        'url': _0x4e1323(0x158) + _0x4e1323(0x135) + _0x4e1323(0x141) + _0x4e1323(0x154) + _0x4e1323(0x12c) + _0x4e1323(0x179)
                    })
                }, {
                    'name': _0x22833c[_0x4e1323(0x13a)],
                    'buttonParamsJson': JSON[_0x4e1323(0x11d)]({
                        'display_text': _0x22833c[_0x4e1323(0x125)],
                        'id': _0x22833c[_0x4e1323(0x15e)]
                    })
                });
                let _0x285cd9 = _0x22833c[_0x4e1323(0x177)](generateWAMessageFromContent, _0x335120[_0x4e1323(0x146)], {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto[_0x4e1323(0x15a)][_0x4e1323(0x123) + _0x4e1323(0x16e)][_0x4e1323(0x12e)]({
                                'body': proto[_0x4e1323(0x15a)][_0x4e1323(0x123) + _0x4e1323(0x16e)][_0x4e1323(0x112)][_0x4e1323(0x12e)]({ 'text': _0x23a58f }),
                                'footer': proto[_0x4e1323(0x15a)][_0x4e1323(0x123) + _0x4e1323(0x16e)][_0x4e1323(0x137)][_0x4e1323(0x12e)]({ 'text': _0x22833c[_0x4e1323(0x121)] }),
                                'header': proto[_0x4e1323(0x15a)][_0x4e1323(0x123) + _0x4e1323(0x16e)][_0x4e1323(0x115)][_0x4e1323(0x12e)]({
                                    'title': '',
                                    'subtitle': '',
                                    'hasMediaAttachment': ![]
                                }),
                                'nativeFlowMessage': proto[_0x4e1323(0x15a)][_0x4e1323(0x123) + _0x4e1323(0x16e)][_0x4e1323(0x180) + _0x4e1323(0x15a)][_0x4e1323(0x12e)]({ 'buttons': _0x3da489 })
                            })
                        }
                    }
                }, {});
                await _0x3739f0[_0x4e1323(0x106) + 'ge'](_0x285cd9[_0x4e1323(0x168)][_0x4e1323(0x15b)], _0x285cd9[_0x4e1323(0x109)], { 'messageId': _0x285cd9[_0x4e1323(0x168)]['id'] }), await _0x335120[_0x4e1323(0x182)]('✅');
            } catch (_0x19202c) {
                console[_0x4e1323(0x138)](_0x22833c[_0x4e1323(0x149)], _0x19202c[_0x4e1323(0x109)]), _0x335120[_0x4e1323(0x130)](_0x22833c[_0x4e1323(0x147)]), await _0x335120[_0x4e1323(0x182)]('❌');
            }
        }
    };
export default gptResponse;
