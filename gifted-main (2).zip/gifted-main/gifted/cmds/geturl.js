function _0xe2ae(_0x48fda5, _0x390460) {
    const _0x39c137 = _0x4299();
    return _0xe2ae = function (_0x17e714, _0x311185) {
        _0x17e714 = _0x17e714 - (-0x1f5 * 0x13 + 0x2073 + 0x139 * 0x5);
        let _0x506025 = _0x39c137[_0x17e714];
        return _0x506025;
    }, _0xe2ae(_0x48fda5, _0x390460);
}
function _0x4299() {
    const _0x446d1a = [
        'TATfu',
        'aVvFl',
        '4251952BXywkI',
        'OFdKH',
        'split',
        'includes',
        'essing\x20med',
        'prSdj',
        'HjzTA',
        '*「▰▰▰▱▱▱▱▱',
        'quoted',
        '▱▱」*',
        'LeOyg',
        'download',
        '3459568sAucaU',
        'EriDh',
        'bIfHw',
        'WtwZM',
        'fHNkq',
        'imageMessa',
        '▰▰」*',
        'dkPti',
        'image',
        'tourl',
        'XuSGD',
        'match',
        '*「▰▰▰▰▱▱▱▱',
        'from',
        'e\x20limit\x20of',
        'dia\x20type.',
        '\x20with\x20an\x20i',
        '*「▰▰▰▰▰▱▱▱',
        '*「▰▰▰▰▰▰▰▰',
        'MB.',
        'aDEgW',
        'glBaA',
        'geturl',
        'sendMessag',
        'length',
        'DvdXx',
        'audioMessa',
        'dyFRN',
        '\x20Here\x20Is\x20Y',
        '3723351hFdsQu',
        'QxOWS',
        'Error\x20proc',
        'audio',
        'Rpgeb',
        'ia:',
        'qFhPf',
        'error',
        'ia.',
        '130dkjzmJ',
        'video',
        'tKczf',
        'CvocR',
        'OkTvf',
        'mp4',
        '✅\x20Loading\x20',
        'Hizdp',
        'lHYUd',
        'tvmoJ',
        'pushName',
        'alRic',
        'GXbqr',
        'jpg',
        'url',
        'our\x20Media*',
        'mVEcz',
        'toLowerCas',
        'mtype',
        'MOAHq',
        '109932nGSbiQ',
        'FAjbW',
        'o\x20to\x20uploa',
        'AKiya',
        'xJsex',
        'edia.',
        'uwWXG',
        'mage,\x20vide',
        'qDbiT',
        'mp3',
        'complete.',
        'o,\x20or\x20audi',
        'GLXGh',
        'OJbhl',
        '130JsHlJn',
        'download\x20m',
        '*「▰▰▰▰▰▰▰▱',
        '*Hey\x20',
        'Failed\x20to\x20',
        'exceeds\x20th',
        'grxAt',
        'reply',
        '▰▱」*',
        'slice',
        'videoMessa',
        'body',
        'Unknown\x20me',
        '*「▰▰▰▰▰▰▱▱',
        'DLrhA',
        '1155222fdzCyj',
        '\x0a*url:*\x20',
        'now',
        'startsWith',
        '7DFsszE',
        'DNyYS',
        'File\x20size\x20',
        'STcXq',
        '4666585IXdylG',
        '3209KgEGpt',
        'Send/Reply'
    ];
    _0x4299 = function () {
        return _0x446d1a;
    };
    return _0x4299();
}
(function (_0x219617, _0x50d5ea) {
    const _0x59e859 = _0xe2ae, _0x1941b5 = _0x219617();
    while (!![]) {
        try {
            const _0x12aaee = -parseInt(_0x59e859(0x1a1)) / (-0x213d + 0x1 * -0x16b5 + 0x1 * 0x37f3) * (parseInt(_0x59e859(0x167)) / (0x1046 * -0x1 + 0x1271 + -0x229)) + -parseInt(_0x59e859(0x1ce)) / (-0x3 * -0x9db + -0x1 * 0x4ae + -0x18e0) + parseInt(_0x59e859(0x1b1)) / (-0x130c + 0x1f88 * -0x1 + -0x2 * -0x194c) + -parseInt(_0x59e859(0x1a0)) / (-0x8 + -0x1682 + 0x168f) + -parseInt(_0x59e859(0x17b)) / (0x1f50 + -0x452 * 0x7 + -0x10c) + -parseInt(_0x59e859(0x19c)) / (-0x3 * 0x505 + -0x20d0 + -0x1 * -0x2fe6) * (-parseInt(_0x59e859(0x1a5)) / (0x853 * -0x4 + 0xfb6 * -0x2 + 0x40c0)) + -parseInt(_0x59e859(0x198)) / (0x1552 + -0x1 * -0x1bf5 + 0x16 * -0x23d) * (-parseInt(_0x59e859(0x189)) / (0x1fd * 0xb + 0x6 * -0x40b + 0x26d * 0x1));
            if (_0x12aaee === _0x50d5ea)
                break;
            else
                _0x1941b5['push'](_0x1941b5['shift']());
        } catch (_0x5af24f) {
            _0x1941b5['push'](_0x1941b5['shift']());
        }
    }
}(_0x4299, 0x716ef + -0x4f41a + 0x159 * 0x5ee));
import {
    UploadFileUgu,
    TelegraPh
} from '../giftedte.js';
import {
    writeFile,
    unlink
} from 'fs/promises';
const MAX_FILE_SIZE_MB = -0xe6e + -0x1 * 0x131 + 0xfb3, tourl = async (_0x1d2d83, _0x1963ac) => {
        const _0x4bc6c8 = _0xe2ae, _0xbf5710 = {
                'xJsex': function (_0x4d82d8, _0x12e4f0) {
                    return _0x4d82d8 % _0x12e4f0;
                },
                'MOAHq': function (_0x3d5810, _0x43c85a) {
                    return _0x3d5810 + _0x43c85a;
                },
                'aVvFl': _0x4bc6c8(0x1ba),
                'DLrhA': _0x4bc6c8(0x1c7),
                'OJbhl': _0x4bc6c8(0x175),
                'HjzTA': _0x4bc6c8(0x1b6) + 'ge',
                'glBaA': _0x4bc6c8(0x193) + 'ge',
                'dkPti': _0x4bc6c8(0x1cb) + 'ge',
                'TATfu': function (_0x2685d0, _0x43a8ab) {
                    return _0x2685d0 + _0x43a8ab;
                },
                'qFhPf': _0x4bc6c8(0x1ac) + _0x4bc6c8(0x1ae),
                'alRic': _0x4bc6c8(0x1bd) + _0x4bc6c8(0x1ae),
                'STcXq': _0x4bc6c8(0x1c2) + _0x4bc6c8(0x1ae),
                'lHYUd': _0x4bc6c8(0x196) + _0x4bc6c8(0x1ae),
                'DNyYS': _0x4bc6c8(0x18b) + _0x4bc6c8(0x1ae),
                'FAjbW': _0x4bc6c8(0x1c3) + _0x4bc6c8(0x1ae),
                'QxOWS': _0x4bc6c8(0x1c3) + _0x4bc6c8(0x191),
                'qDbiT': _0x4bc6c8(0x1c3) + _0x4bc6c8(0x1b7),
                'tKczf': function (_0x2bb28e, _0x5985a4, _0x2603b3) {
                    return _0x2bb28e(_0x5985a4, _0x2603b3);
                },
                'Rpgeb': _0x4bc6c8(0x18d) + _0x4bc6c8(0x18a) + _0x4bc6c8(0x180),
                'tvmoJ': function (_0x2d875b, _0x58f5e6) {
                    return _0x2d875b / _0x58f5e6;
                },
                'WtwZM': function (_0x3dcd54, _0x2660b6) {
                    return _0x3dcd54 * _0x2660b6;
                },
                'prSdj': function (_0x11fb05, _0x81065c) {
                    return _0x11fb05 > _0x81065c;
                },
                'OkTvf': function (_0x5b9671, _0x580afc) {
                    return _0x5b9671(_0x580afc);
                },
                'DvdXx': _0x4bc6c8(0x195) + _0x4bc6c8(0x1c0),
                'CvocR': function (_0x395675, _0x35ab38) {
                    return _0x395675 === _0x35ab38;
                },
                'XuSGD': _0x4bc6c8(0x16d) + _0x4bc6c8(0x185),
                'GXbqr': _0x4bc6c8(0x1d0) + _0x4bc6c8(0x1a9) + _0x4bc6c8(0x163),
                'uwWXG': _0x4bc6c8(0x1d0) + _0x4bc6c8(0x1a9) + _0x4bc6c8(0x166)
            }, _0x212ef2 = _0x1d2d83[_0x4bc6c8(0x194)][_0x4bc6c8(0x1bc)](/^[\\/!#.]/), _0x49dc84 = _0x212ef2 ? _0x212ef2[-0x2 * -0xa29 + 0x1 * -0x7a + -0x13d8] : '/', _0x53ece0 = _0x1d2d83[_0x4bc6c8(0x194)][_0x4bc6c8(0x19b)](_0x49dc84) ? _0x1d2d83[_0x4bc6c8(0x194)][_0x4bc6c8(0x192)](_0x49dc84[_0x4bc6c8(0x1c9)])[_0x4bc6c8(0x1a7)]('\x20')[-0x13b3 + -0x652 + 0x1a05][_0x4bc6c8(0x178) + 'e']() : '', _0x3f10fb = [
                _0xbf5710[_0x4bc6c8(0x1a4)],
                _0xbf5710[_0x4bc6c8(0x197)],
                _0xbf5710[_0x4bc6c8(0x188)]
            ];
        if (_0x3f10fb[_0x4bc6c8(0x1a8)](_0x53ece0)) {
            if (!_0x1d2d83[_0x4bc6c8(0x1ad)] || ![
                    _0xbf5710[_0x4bc6c8(0x1ab)],
                    _0xbf5710[_0x4bc6c8(0x1c6)],
                    _0xbf5710[_0x4bc6c8(0x1b8)]
                ][_0x4bc6c8(0x1a8)](_0x1d2d83[_0x4bc6c8(0x1ad)][_0x4bc6c8(0x179)]))
                return _0x1d2d83[_0x4bc6c8(0x190)](_0x4bc6c8(0x1a2) + _0x4bc6c8(0x1c1) + _0x4bc6c8(0x182) + _0x4bc6c8(0x186) + _0x4bc6c8(0x17d) + 'd\x20' + _0xbf5710[_0x4bc6c8(0x1a3)](_0x49dc84, _0x53ece0));
            try {
                const _0x403ecf = [
                        _0xbf5710[_0x4bc6c8(0x164)],
                        _0xbf5710[_0x4bc6c8(0x172)],
                        _0xbf5710[_0x4bc6c8(0x19f)],
                        _0xbf5710[_0x4bc6c8(0x16f)],
                        _0xbf5710[_0x4bc6c8(0x19d)],
                        _0xbf5710[_0x4bc6c8(0x17c)],
                        _0xbf5710[_0x4bc6c8(0x1cf)],
                        _0xbf5710[_0x4bc6c8(0x183)]
                    ], _0x4e6b5a = _0x403ecf[_0x4bc6c8(0x1c9)];
                let _0x51ba7f = 0x1 * -0x1af3 + 0x34a * -0x1 + 0x1e3d;
                const {key: _0x53205a} = await _0x1963ac[_0x4bc6c8(0x1c8) + 'e'](_0x1d2d83[_0x4bc6c8(0x1be)], { 'text': _0x403ecf[_0x51ba7f] }, { 'quoted': _0x1d2d83 }), _0x444649 = _0xbf5710[_0x4bc6c8(0x169)](setInterval, () => {
                        const _0x386616 = _0x4bc6c8;
                        _0x51ba7f = _0xbf5710[_0x386616(0x17f)](_0xbf5710[_0x386616(0x17a)](_0x51ba7f, -0x752 * 0x4 + 0x3b3 * 0xa + -0x7b5), _0x4e6b5a), _0x1963ac[_0x386616(0x1c8) + 'e'](_0x1d2d83[_0x386616(0x1be)], { 'text': _0x403ecf[_0x51ba7f] }, {
                            'quoted': _0x1d2d83,
                            'messageId': _0x53205a
                        });
                    }, 0x1 * 0xbdd + 0x1 * -0x1b87 + 0x119e), _0x3ed35f = await _0x1d2d83[_0x4bc6c8(0x1ad)][_0x4bc6c8(0x1b0)]();
                if (!_0x3ed35f)
                    throw new Error(_0xbf5710[_0x4bc6c8(0x162)]);
                const _0x22dd73 = _0xbf5710[_0x4bc6c8(0x170)](_0x3ed35f[_0x4bc6c8(0x1c9)], _0xbf5710[_0x4bc6c8(0x1b4)](0x2ab * -0x5 + -0x2387 + 0x34de, 0x14c3 * 0x1 + 0x3 * 0x5c9 + 0xb * -0x31a));
                if (_0xbf5710[_0x4bc6c8(0x1aa)](_0x22dd73, MAX_FILE_SIZE_MB))
                    return _0xbf5710[_0x4bc6c8(0x16b)](clearInterval, _0x444649), _0x1d2d83[_0x4bc6c8(0x190)](_0x4bc6c8(0x19e) + _0x4bc6c8(0x18e) + _0x4bc6c8(0x1bf) + '\x20' + MAX_FILE_SIZE_MB + _0x4bc6c8(0x1c4));
                const _0x35d599 = _0xbf5710[_0x4bc6c8(0x16b)](getFileExtension, _0x1d2d83[_0x4bc6c8(0x1ad)][_0x4bc6c8(0x179)]);
                if (!_0x35d599)
                    throw new Error(_0xbf5710[_0x4bc6c8(0x1ca)]);
                const _0xf2b3a9 = './' + Date[_0x4bc6c8(0x19a)]() + '.' + _0x35d599;
                await _0xbf5710[_0x4bc6c8(0x169)](writeFile, _0xf2b3a9, _0x3ed35f);
                let _0x20e9ee;
                _0xbf5710[_0x4bc6c8(0x16a)](_0x1d2d83[_0x4bc6c8(0x1ad)][_0x4bc6c8(0x179)], _0xbf5710[_0x4bc6c8(0x1ab)]) ? _0x20e9ee = await _0xbf5710[_0x4bc6c8(0x16b)](TelegraPh, _0xf2b3a9) : _0x20e9ee = await _0xbf5710[_0x4bc6c8(0x16b)](UploadFileUgu, _0xf2b3a9);
                _0xbf5710[_0x4bc6c8(0x16b)](clearInterval, _0x444649), await _0x1963ac[_0x4bc6c8(0x1c8) + 'e'](_0x1d2d83[_0x4bc6c8(0x1be)], { 'text': _0xbf5710[_0x4bc6c8(0x1bb)] }, { 'quoted': _0x1d2d83 });
                const _0xdaea32 = _0xbf5710[_0x4bc6c8(0x16b)](getMediaType, _0x1d2d83[_0x4bc6c8(0x1ad)][_0x4bc6c8(0x179)]), _0x2cdf34 = _0x20e9ee[_0x4bc6c8(0x175)] || _0x20e9ee, _0x401e88 = {
                        [_0xdaea32]: { 'url': _0x2cdf34 },
                        'caption': _0x4bc6c8(0x18c) + _0x1d2d83[_0x4bc6c8(0x171)] + (_0x4bc6c8(0x1cd) + _0x4bc6c8(0x176) + _0x4bc6c8(0x199)) + _0x2cdf34
                    };
                await _0x1963ac[_0x4bc6c8(0x1c8) + 'e'](_0x1d2d83[_0x4bc6c8(0x1be)], _0x401e88, { 'quoted': _0x1d2d83 }), await _0xbf5710[_0x4bc6c8(0x16b)](unlink, _0xf2b3a9);
            } catch (_0x5c88f1) {
                console[_0x4bc6c8(0x165)](_0xbf5710[_0x4bc6c8(0x173)], _0x5c88f1), _0x1d2d83[_0x4bc6c8(0x190)](_0xbf5710[_0x4bc6c8(0x181)]);
            }
        }
    }, getFileExtension = _0x180fef => {
        const _0x9b0354 = _0xe2ae, _0x151978 = {
                'AKiya': _0x9b0354(0x1b6) + 'ge',
                'GLXGh': _0x9b0354(0x174),
                'EriDh': _0x9b0354(0x193) + 'ge',
                'grxAt': _0x9b0354(0x16c),
                'LeOyg': _0x9b0354(0x1cb) + 'ge',
                'fHNkq': _0x9b0354(0x184)
            };
        switch (_0x180fef) {
        case _0x151978[_0x9b0354(0x17e)]:
            return _0x151978[_0x9b0354(0x187)];
        case _0x151978[_0x9b0354(0x1b2)]:
            return _0x151978[_0x9b0354(0x18f)];
        case _0x151978[_0x9b0354(0x1af)]:
            return _0x151978[_0x9b0354(0x1b5)];
        default:
            return null;
        }
    }, getMediaType = _0x17f056 => {
        const _0x14cd4e = _0xe2ae, _0x37e0ec = {
                'mVEcz': _0x14cd4e(0x1b6) + 'ge',
                'Hizdp': _0x14cd4e(0x1b9),
                'OFdKH': _0x14cd4e(0x193) + 'ge',
                'bIfHw': _0x14cd4e(0x168),
                'dyFRN': _0x14cd4e(0x1cb) + 'ge',
                'aDEgW': _0x14cd4e(0x161)
            };
        switch (_0x17f056) {
        case _0x37e0ec[_0x14cd4e(0x177)]:
            return _0x37e0ec[_0x14cd4e(0x16e)];
        case _0x37e0ec[_0x14cd4e(0x1a6)]:
            return _0x37e0ec[_0x14cd4e(0x1b3)];
        case _0x37e0ec[_0x14cd4e(0x1cc)]:
            return _0x37e0ec[_0x14cd4e(0x1c5)];
        default:
            return null;
        }
    };
export default tourl;
