(function (_0x27e1c0, _0x5190da) {
    const _0x541180 = _0x5e2a, _0x2458c0 = _0x27e1c0();
    while (!![]) {
        try {
            const _0x3200df = -parseInt(_0x541180(0xa5)) / (-0x1970 + 0x1849 + 0x94 * 0x2) + -parseInt(_0x541180(0xc0)) / (-0x46d + 0x209e + 0x41 * -0x6f) + parseInt(_0x541180(0x91)) / (-0x246 + 0x1195 * -0x2 + 0x2573) + -parseInt(_0x541180(0x98)) / (0x1c7d + -0x13d * 0x17 + 0x2) * (-parseInt(_0x541180(0x9b)) / (0x18e3 + 0x370 * 0x5 + -0x2a0e * 0x1)) + parseInt(_0x541180(0xbc)) / (-0x690 + 0x187c + -0x11e6) * (-parseInt(_0x541180(0xc5)) / (-0x21d2 + 0x1 * 0x685 + -0x13e * -0x16)) + -parseInt(_0x541180(0xcf)) / (0x4 * 0x829 + -0x1 * 0xa15 + -0x1687) * (-parseInt(_0x541180(0xd2)) / (-0x5 * -0x25 + 0x18c4 + -0x1974)) + parseInt(_0x541180(0x96)) / (0x24f0 + 0x3 * -0x3fb + 0x18f5 * -0x1);
            if (_0x3200df === _0x5190da)
                break;
            else
                _0x2458c0['push'](_0x2458c0['shift']());
        } catch (_0x5f62d) {
            _0x2458c0['push'](_0x2458c0['shift']());
        }
    }
}(_0x48f5, 0x4ba0f + -0x4b128 + 0x97388));
import { GiftedGpt } from 'gifted-gpt';
function _0x5e2a(_0x579320, _0x2b3c74) {
    const _0x31c86f = _0x48f5();
    return _0x5e2a = function (_0x40a7a7, _0x4e8c69) {
        _0x40a7a7 = _0x40a7a7 - (0x1d79 * 0x1 + 0x4c1 * -0x1 + -0x1838);
        let _0x4c898d = _0x31c86f[_0x40a7a7];
        return _0x4c898d;
    }, _0x5e2a(_0x579320, _0x2b3c74);
}
function _0x48f5() {
    const _0x27778c = [
        'Xsvrh',
        'system',
        'ccepts\x20com',
        'crosoft.',
        '*_\x20,\x20Pleas',
        'ng\x20of\x20Gift',
        '1934736BOsPtH',
        'match',
        'Error\x20fetc',
        '45YLPXJH',
        'lease\x20try\x20',
        'UopXD',
        'pushName',
        '\x20the\x20meani',
        'length',
        'Connecting',
        'trim',
        'e\x20provide\x20',
        'retrieve\x20A',
        'ed*',
        '\x20work\x20cour',
        'ses\x20users\x20',
        'OJuHS',
        'toLowerCas',
        't\x20called\x20G',
        'reply',
        'providers',
        '3602997rvGgFD',
        'error',
        'UgBcM',
        'pi\x20data.\x20P',
        'gpt4v2',
        '177130YGZFqP',
        'sendMessag',
        '27752CDBcOP',
        'gifted',
        'ifted-Md\x20t',
        '715oDeIKq',
        'JijDP',
        'text\x20and\x20a',
        'Gbraf',
        'from',
        'tesy\x20of\x20Bi',
        'hat\x20proces',
        'ng\x20from\x20Mi',
        'your\x20query',
        'slice',
        '529211axnNaB',
        'tion',
        'GPT',
        'EeCZw',
        'chatgptv2',
        'Failed\x20to\x20',
        ',\x20e.g.,\x20*.',
        'mands.\x20You',
        'fPxrM',
        'davinci',
        'ai\x20What\x20is',
        '\x20to\x20Gifted',
        'hatsApp\x20bo',
        'A\x20moment,\x20',
        'chatgpt4v2',
        'ata:',
        'again\x20late',
        'kHNCt',
        'includes',
        'iEkCQ',
        '-Api...',
        'ixJkD',
        'chatComple',
        '6269832KUpIaa',
        'body',
        'Hello\x20_*',
        'startsWith',
        '2448388JbUala',
        'split',
        'React',
        'Frocl',
        'hing\x20Api\x20d',
        '7qwZwla',
        'You\x27re\x20a\x20W',
        'user',
        'gptv2'
    ];
    _0x48f5 = function () {
        return _0x27778c;
    };
    return _0x48f5();
}
const gpt4 = new GiftedGpt(), AiGifted = async (_0x3c99ab, _0x2a2231) => {
        const _0x451437 = _0x5e2a, _0x2db83a = {
                'Frocl': function (_0x172ab1, _0x31a5e1) {
                    return _0x172ab1 + _0x31a5e1;
                },
                'UgBcM': _0x451437(0x99),
                'iEkCQ': _0x451437(0xa9),
                'JijDP': _0x451437(0xb3),
                'UopXD': _0x451437(0xc8),
                'fPxrM': _0x451437(0x95),
                'Gbraf': _0x451437(0xca),
                'Xsvrh': _0x451437(0xc6) + _0x451437(0xb1) + _0x451437(0x8e) + _0x451437(0x9a) + _0x451437(0xa1) + _0x451437(0x8b) + _0x451437(0x9d) + _0x451437(0xcb) + _0x451437(0xac) + _0x451437(0x8a) + _0x451437(0xa0) + _0x451437(0xa2) + _0x451437(0xcc),
                'EeCZw': _0x451437(0xc7),
                'OJuHS': _0x451437(0xae),
                'ixJkD': _0x451437(0xd1) + _0x451437(0xc4) + _0x451437(0xb4),
                'kHNCt': _0x451437(0xaa) + _0x451437(0x88) + _0x451437(0x94) + _0x451437(0x80) + _0x451437(0xb5) + 'r.'
            }, _0x55d76e = _0x3c99ab[_0x451437(0xbd)][_0x451437(0xd0)](/^[\\/!#.]/), _0x5c738a = _0x55d76e ? _0x55d76e[0x968 * -0x3 + -0x12c9 + 0x2f01] : '/', _0xc33afa = _0x3c99ab[_0x451437(0xbd)][_0x451437(0xbf)](_0x5c738a) ? _0x3c99ab[_0x451437(0xbd)][_0x451437(0xa4)](_0x5c738a[_0x451437(0x84)])[_0x451437(0xc1)]('\x20')[-0xd * 0x27e + -0x2 * -0x732 + 0x2 * 0x901][_0x451437(0x8d) + 'e']() : '', _0x15f1f4 = _0x3c99ab[_0x451437(0xbd)][_0x451437(0xa4)](_0x2db83a[_0x451437(0xc3)](_0x5c738a[_0x451437(0x84)], _0xc33afa[_0x451437(0x84)]))[_0x451437(0x86)](), _0x442cf7 = [
                _0x2db83a[_0x451437(0x93)],
                'ai',
                _0x2db83a[_0x451437(0xb8)],
                _0x2db83a[_0x451437(0x9c)],
                _0x2db83a[_0x451437(0x81)],
                _0x2db83a[_0x451437(0xad)]
            ];
        if (_0x442cf7[_0x451437(0xb7)](_0xc33afa)) {
            !_0x15f1f4 && await _0x3c99ab[_0x451437(0x8f)](_0x451437(0xbe) + _0x3c99ab[_0x451437(0x82)] + (_0x451437(0xcd) + _0x451437(0x87) + _0x451437(0xa3) + _0x451437(0xab) + _0x451437(0xaf) + _0x451437(0x83) + _0x451437(0xce) + _0x451437(0x89)));
            try {
                await _0x3c99ab[_0x451437(0xc2)]('🕘'), await _0x3c99ab[_0x451437(0x8f)](_0x451437(0xb2) + _0x451437(0x85) + _0x451437(0xb0) + _0x451437(0xb9));
                const _0x25cc50 = [
                        {
                            'role': _0x2db83a[_0x451437(0x9e)],
                            'content': _0x2db83a[_0x451437(0xc9)]
                        },
                        {
                            'role': _0x2db83a[_0x451437(0xa8)],
                            'content': _0x15f1f4
                        }
                    ], _0x55777a = {
                        'provider': gpt4[_0x451437(0x90)][_0x451437(0xa7)],
                        'model': _0x2db83a[_0x451437(0x8c)],
                        'debug': !![],
                        'proxy': ''
                    }, _0x194c9d = await gpt4[_0x451437(0xbb) + _0x451437(0xa6)](_0x25cc50, _0x55777a), _0x1ad210 = _0x194c9d;
                await _0x2a2231[_0x451437(0x97) + 'e'](_0x3c99ab[_0x451437(0x9f)], { 'text': _0x1ad210 }, { 'quoted': _0x3c99ab }), await _0x3c99ab[_0x451437(0xc2)]('✅');
            } catch (_0x1f4653) {
                console[_0x451437(0x92)](_0x2db83a[_0x451437(0xba)], _0x1f4653), await _0x2a2231[_0x451437(0x97) + 'e'](_0x3c99ab[_0x451437(0x9f)], { 'text': _0x2db83a[_0x451437(0xb6)] });
            }
        }
    };
export default AiGifted;
