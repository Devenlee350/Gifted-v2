(function (_0x390259, _0x4772e7) {
    const _0x395b26 = _0x10a8, _0x58c031 = _0x390259();
    while (!![]) {
        try {
            const _0x1c6189 = parseInt(_0x395b26(0x1c9)) / 0x1 + parseInt(_0x395b26(0x1cb)) / 0x2 + -parseInt(_0x395b26(0x1c0)) / 0x3 * (parseInt(_0x395b26(0x1c1)) / 0x4) + parseInt(_0x395b26(0x1ca)) / 0x5 * (-parseInt(_0x395b26(0x1b8)) / 0x6) + parseInt(_0x395b26(0x1c6)) / 0x7 + parseInt(_0x395b26(0x1be)) / 0x8 * (-parseInt(_0x395b26(0x1bf)) / 0x9) + -parseInt(_0x395b26(0x1bc)) / 0xa * (-parseInt(_0x395b26(0x1bd)) / 0xb);
            if (_0x1c6189 === _0x4772e7)
                break;
            else
                _0x58c031['push'](_0x58c031['shift']());
        } catch (_0x347da8) {
            _0x58c031['push'](_0x58c031['shift']());
        }
    }
}(_0x2079, 0x72240));
function _0x10a8(_0x1b6446, _0x571c8f) {
    const _0x20798c = _0x2079();
    return _0x10a8 = function (_0x10a830, _0x175a0f) {
        _0x10a830 = _0x10a830 - 0x1b7;
        let _0x575499 = _0x20798c[_0x10a830];
        return _0x575499;
    }, _0x10a8(_0x1b6446, _0x571c8f);
}
const ping = async (_0x3629aa, _0x186edc) => {
    const _0x1179af = _0x10a8, _0x7a500d = /^[\\/!#.]/gi[_0x1179af(0x1bb)](_0x3629aa['body']) ? _0x3629aa[_0x1179af(0x1ba)][_0x1179af(0x1b7)](/^[\\/!#.]/gi)[0x0] : '/', _0x5be6ba = _0x3629aa['body'][_0x1179af(0x1cd)](_0x7a500d) ? _0x3629aa[_0x1179af(0x1ba)]['slice'](_0x7a500d[_0x1179af(0x1c3)])[_0x1179af(0x1c8)]() : '';
    if (_0x5be6ba === _0x1179af(0x1cc)) {
        const _0x325a34 = new Date(), {key: _0x2eacfa} = await _0x186edc[_0x1179af(0x1c2)](_0x3629aa['from'], { 'text': _0x1179af(0x1c7) }, { 'quoted': _0x3629aa });
        await _0x3629aa[_0x1179af(0x1b9)]('🚀');
        const _0x5242a1 = _0x1179af(0x1c5) + (new Date() - _0x325a34) + _0x1179af(0x1ce);
        return await _0x3629aa[_0x1179af(0x1b9)]('⚡'), _0x3629aa[_0x1179af(0x1c4)]('' + _0x5242a1, { 'quoted': _0x2eacfa });
    }
};
function _0x2079() {
    const _0x18ba37 = [
        'sendMessage',
        'length',
        'reply',
        '*_ɢɪғᴛᴇᴅ-ᴍᴅ\x20sᴘᴇᴇᴅ:\x20',
        '4833962tkEaTr',
        '*_ᴘɪɴɢɪɴɢ\x20ᴛᴏ\x20sᴇʀᴠᴇʀ..._*',
        'toLowerCase',
        '585262pslLdO',
        '76255mbkDhX',
        '63136dxNuZq',
        'ping',
        'startsWith',
        '\x20ms_*',
        'match',
        '222FSihjC',
        'React',
        'body',
        'test',
        '2420yQowPW',
        '31361Jpcwuc',
        '1884632SbwmXk',
        '18SwYcsh',
        '639LdpFlI',
        '9284MGamRm'
    ];
    _0x2079 = function () {
        return _0x18ba37;
    };
    return _0x2079();
}
export default ping;
