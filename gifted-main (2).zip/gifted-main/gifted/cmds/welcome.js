(function (_0x3a513a, _0x141dca) {
    const _0x56c953 = _0x4631, _0x195b13 = _0x3a513a();
    while (!![]) {
        try {
            const _0x2c21ec = parseInt(_0x56c953(0xb0)) / 0x1 * (parseInt(_0x56c953(0xb5)) / 0x2) + -parseInt(_0x56c953(0xb4)) / 0x3 + -parseInt(_0x56c953(0xbc)) / 0x4 * (-parseInt(_0x56c953(0xa4)) / 0x5) + parseInt(_0x56c953(0xac)) / 0x6 + -parseInt(_0x56c953(0xbd)) / 0x7 + -parseInt(_0x56c953(0xa7)) / 0x8 * (parseInt(_0x56c953(0xc0)) / 0x9) + parseInt(_0x56c953(0xaa)) / 0xa * (parseInt(_0x56c953(0xbe)) / 0xb);
            if (_0x2c21ec === _0x141dca)
                break;
            else
                _0x195b13['push'](_0x195b13['shift']());
        } catch (_0x36b0cd) {
            _0x195b13['push'](_0x195b13['shift']());
        }
    }
}(_0x2974, 0x3fb70));
import _0x47348e from '../../set.cjs';
const gcEvent = async (_0x2c201f, _0x12e807) => {
    const _0x45b595 = _0x4631, _0x589c97 = _0x2c201f[_0x45b595(0xb8)]['match'](/^[\\/!#.]/), _0x41d50d = _0x589c97 ? _0x589c97[0x0] : '/', _0x12621b = _0x2c201f[_0x45b595(0xb8)][_0x45b595(0xb1)](_0x41d50d) ? _0x2c201f[_0x45b595(0xb8)]['slice'](_0x41d50d[_0x45b595(0xb3)])[_0x45b595(0xbf)]('\x20')[0x0][_0x45b595(0xbb)]() : '', _0x448367 = _0x2c201f[_0x45b595(0xb8)]['slice'](_0x41d50d[_0x45b595(0xb3)] + _0x12621b['length'])['trim']()[_0x45b595(0xbb)]();
    if (_0x12621b === _0x45b595(0xba)) {
        if (!_0x2c201f['isGroup'])
            return _0x2c201f[_0x45b595(0xad)](_0x45b595(0xa8));
        const _0x3cada3 = await _0x12e807['groupMetadata'](_0x2c201f[_0x45b595(0xa3)]), _0x3f9ba9 = _0x3cada3[_0x45b595(0xb2)], _0x3bc268 = await _0x12e807[_0x45b595(0xa9)](_0x12e807[_0x45b595(0xab)]['id']), _0xbc87e6 = _0x3f9ba9[_0x45b595(0xb9)](_0x5a7151 => _0x5a7151['id'] === _0x3bc268)?.[_0x45b595(0xaf)], _0x17cb4b = _0x3f9ba9[_0x45b595(0xb9)](_0x8c92b5 => _0x8c92b5['id'] === _0x2c201f[_0x45b595(0xb7)])?.[_0x45b595(0xaf)];
        if (!_0xbc87e6)
            return _0x2c201f[_0x45b595(0xad)]('*📛\x20BOT\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*');
        if (!_0x17cb4b)
            return _0x2c201f[_0x45b595(0xad)](_0x45b595(0xa6));
        let _0x79f3bc;
        if (_0x448367 === 'on')
            _0x47348e['WELCOME'] = !![], _0x79f3bc = 'WELCOME\x20&\x20LEFT\x20message\x20has\x20been\x20Enabled.';
        else
            _0x448367 === _0x45b595(0xae) ? (_0x47348e[_0x45b595(0xa5)] = ![], _0x79f3bc = 'WELCOME\x20&\x20LEFT\x20message\x20has\x20been\x20Disabled.') : _0x79f3bc = _0x45b595(0xc3);
        try {
            await _0x12e807[_0x45b595(0xc1)](_0x2c201f[_0x45b595(0xa3)], { 'text': _0x79f3bc }, { 'quoted': _0x2c201f });
        } catch (_0x26e0dd) {
            console[_0x45b595(0xb6)](_0x45b595(0xc2), _0x26e0dd), await _0x12e807[_0x45b595(0xc1)](_0x2c201f['from'], { 'text': 'Error\x20processing\x20your\x20request.' }, { 'quoted': _0x2c201f });
        }
    }
};
function _0x4631(_0x8f8de5, _0x3caf25) {
    const _0x2974e5 = _0x2974();
    return _0x4631 = function (_0x463191, _0x32ae3b) {
        _0x463191 = _0x463191 - 0xa3;
        let _0x200fa3 = _0x2974e5[_0x463191];
        return _0x200fa3;
    }, _0x4631(_0x8f8de5, _0x3caf25);
}
export default gcEvent;
function _0x2974() {
    const _0x2a65e8 = [
        '1524738AgsePr',
        'reply',
        'off',
        'admin',
        '143579oVFcyM',
        'startsWith',
        'participants',
        'length',
        '1130931fdtLPb',
        '2eMvdrr',
        'error',
        'sender',
        'body',
        'find',
        'welcome',
        'toLowerCase',
        '4jWaiCM',
        '772317tOTCmZ',
        '75427lszSao',
        'split',
        '14787BkcUjh',
        'sendMessage',
        'Error\x20processing\x20your\x20request:',
        'Usage:\x0a-\x20`WELCOME\x20on`:\x20Enable\x20WELCOME\x20&\x20LEFT\x20message\x0a-\x20`WELCOME\x20off`:\x20Disable\x20WELCOME\x20&\x20LEFT\x20message',
        'from',
        '409595ZLBfGj',
        'WELCOME',
        '*📛\x20YOU\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*',
        '2064fVsutP',
        '*📛\x20THIS\x20COMMAND\x20CAN\x20ONLY\x20BE\x20USED\x20IN\x20GROUPS*',
        'decodeJid',
        '1010owvvPZ',
        'user'
    ];
    _0x2974 = function () {
        return _0x2a65e8;
    };
    return _0x2974();
}
