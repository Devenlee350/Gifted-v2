(function (_0x33033c, _0x32366e) {
    const _0x55dcf3 = _0x5a33, _0x2f9f4d = _0x33033c();
    while (!![]) {
        try {
            const _0x5c2e3f = parseInt(_0x55dcf3(0x20d)) / (-0xae2 * -0x3 + 0x2 * -0x1307 + 0x569) + parseInt(_0x55dcf3(0x1ae)) / (-0x239e + 0xcc * 0x4 + 0x40e * 0x8) * (parseInt(_0x55dcf3(0x194)) / (0xd30 + 0xec3 + 0x12a * -0x18)) + parseInt(_0x55dcf3(0x192)) / (0x78a * -0x2 + 0x347 + 0x79 * 0x19) + -parseInt(_0x55dcf3(0x240)) / (-0x1 * -0x566 + -0x1c81 + 0x1720) + parseInt(_0x55dcf3(0x234)) / (0xcca * -0x1 + 0x3 * 0x9a3 + -0x1019) + -parseInt(_0x55dcf3(0x1b1)) / (0x25dc + -0x1894 + -0x105 * 0xd) + -parseInt(_0x55dcf3(0x1e3)) / (0xb41 * -0x3 + 0x107e + -0x114d * -0x1);
            if (_0x5c2e3f === _0x32366e)
                break;
            else
                _0x2f9f4d['push'](_0x2f9f4d['shift']());
        } catch (_0x2f6fe8) {
            _0x2f9f4d['push'](_0x2f9f4d['shift']());
        }
    }
}(_0x36b7, 0x101df7 + 0x32 * -0x2ed8 + 0x248b7 * 0x1));
function _0x5a33(_0x1d36a2, _0x31d7c9) {
    const _0x55f359 = _0x36b7();
    return _0x5a33 = function (_0xc842ec, _0x18f463) {
        _0xc842ec = _0xc842ec - (-0xeb1 + 0x19d * 0x3 + 0xb5d);
        let _0xdcf5e0 = _0x55f359[_0xc842ec];
        return _0xdcf5e0;
    }, _0x5a33(_0x1d36a2, _0x31d7c9);
}
import _0x1a5cbf from 'yt-search';
import _0x41c730 from 'axios';
import _0x400074, { prepareWAMessageMedia } from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = _0x400074, videoMap = new Map();
function _0x36b7() {
    const _0x308fd6 = [
        '𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑*',
        'pQxIj',
        'url=https:',
        '299118YYrUDB',
        'vxKsg',
        'Error\x20fetc',
        '7245217nXqrjD',
        'ect',
        'React',
        'download_u',
        'DOtfi',
        'Please\x20pro',
        'https://wh',
        '𝐌𝐃\x20𝐕𝐈𝐃𝐄𝐎\x20𝐃',
        'Error\x20proc',
        'Hcjkd',
        'FNTvQ',
        'audio/mpeg',
        'hing\x20video',
        'ttonReplyM',
        'ults\x20-\x20Vid',
        'remoteJid',
        'ResponseMe',
        'message',
        '𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌',
        'steYp',
        'selectedId',
        'ercSb',
        '\x20ᴠɪᴅᴇᴏ',
        'Interactiv',
        'uery',
        '_\x0a*Artist:',
        'gifteddevs',
        'sponse\x20fro',
        'tch?v=',
        '/api/downl',
        'vide\x20a\x20You',
        'waUploadTo',
        'relayMessa',
        'IbvUb',
        'QuPQM',
        'r\x20request:',
        'split',
        'templateBu',
        'A\x20moment,\x20',
        'from',
        '*Gifted-Md',
        'oaApN',
        'oad/ytmp3?',
        '\x20details:',
        '*\x20is\x20Gener',
        'body',
        '🎥\x20sᴇʟᴇᴄᴛ\x20ᴀ',
        'essing\x20you',
        'seconds',
        'ating\x20Down',
        '1963720CRbrPr',
        'create',
        '029VaYauR9',
        's_\x0a*Views:',
        'author',
        'stringify',
        'get',
        'atsapp.com',
        'NVDJy',
        'https://ww',
        '.mp3',
        'ssage',
        'm\x20the\x20API.',
        'parse',
        'startsWith',
        'BfdkX',
        'Server',
        'toLowerCas',
        '𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑',
        'oad/ytmp4?',
        'Header',
        'videoId',
        'thumbnail',
        '𝟓*',
        ':*\x20',
        'bTSDn',
        '/channel/0',
        'Body',
        'ults\x20-\x20Aud',
        '🎵audio_',
        'ɴ\x20ᴀᴜᴅɪᴏ',
        'MfhWe',
        'aJbfj',
        'cta_url',
        'i1l',
        'aArbd',
        'https://ap',
        'replace',
        '\x0a*Artist:*',
        '//www.yout',
        '🤩\x20Top\x2050',
        '🎦video_',
        '551238kVFARX',
        '𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20',
        'cXDKf',
        'title',
        'No\x20results',
        'n:*\x20_',
        'videos',
        'ios',
        '\x20Gifted\x20Te',
        'Message',
        'KymrF',
        'JDcCf',
        'includes',
        'VYeWq',
        '\x20ɢɪғᴛᴇᴅ',
        'CDQUU',
        'ctpFY',
        '&apikey=',
        'Footer',
        'ns...',
        'ytsearch',
        'JPQUB',
        'match',
        'ube.com/wa',
        'video/mp4',
        '😎\x20Top\x2050\x20Y',
        'eMessage',
        'Invalid\x20re',
        'essage',
        'length',
        '*Tittle:*\x20',
        '𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕',
        'eos',
        'KHBWu',
        '🎶\x20Top\x2050\x20Y',
        'i.giftedte',
        'bxltv',
        'single_sel',
        'Powered\x20by',
        '5719578UYwPKw',
        'data',
        'twraf',
        'TGsEB',
        'sʜᴏᴡ\x20💜\x20ғᴏʀ',
        'ISTkHTj4xv',
        'r\x20request.',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆',
        'name',
        'ptTVd',
        'set',
        'com/watch?',
        '4882405TZoDyF',
        's\x0a\x0a>\x20*©𝟐𝟎𝟐',
        'ouTube\x20Res',
        'trim',
        'map',
        'MexsO',
        'sender',
        '🎧\x20sᴇʟᴇᴄᴛ\x20ᴀ',
        '*\x20_',
        'load\x20Butto',
        '\x0a\x0a*Tittle:',
        'sendMessag',
        'chnexus.co',
        'interactiv',
        '_\x0a*Link:*\x20',
        '_\x0a*Duratio',
        'error',
        'kOtop',
        'beqhM',
        '1247588tOAGTr',
        '.mp4',
        '21ADtMux',
        'JtyOm',
        'duration',
        'Tube\x20URL\x20o',
        '\x20found.',
        '.ke',
        'reply',
        'w.youtube.',
        'result',
        'qLbRE',
        'views',
        '>\x20*𝐆𝐈𝐅𝐓𝐄𝐃-',
        'key',
        'nativeFlow',
        '𝐃\x20𝐕𝟓*',
        '\x0a*Duration',
        'r\x20search\x20q',
        'paramsJson',
        'NativeFlow',
        'eResponseM',
        'jqMeX',
        'yts',
        'slice'
    ];
    _0x36b7 = function () {
        return _0x308fd6;
    };
    return _0x36b7();
}
let videoIndex = 0x3 * -0x83a + -0x2654 + -0x1 * -0x3f03, audioIndex = 0x9f3 + -0x1bfe + 0x464 * 0x5;
const song = async (_0x273f7b, _0x51f934) => {
    const _0x175ff9 = _0x5a33, _0x3e5332 = {
            'oaApN': function (_0xc3765c, _0x24b3db) {
                return _0xc3765c + _0x24b3db;
            },
            'cXDKf': function (_0x582552, _0x139700) {
                return _0x582552 || _0x139700;
            },
            'bxltv': _0x175ff9(0x207) + _0x175ff9(0x230) + _0x175ff9(0x18b) + _0x175ff9(0x199),
            'MfhWe': _0x175ff9(0x1cb) + 'kk',
            'TGsEB': _0x175ff9(0x1a9),
            'kOtop': _0x175ff9(0x221),
            'ercSb': _0x175ff9(0x1b6) + _0x175ff9(0x1cf) + _0x175ff9(0x197) + _0x175ff9(0x1a4) + _0x175ff9(0x1c9),
            'FNTvQ': _0x175ff9(0x1d7) + _0x175ff9(0x1d9) + _0x175ff9(0x1dd) + _0x175ff9(0x1e2) + _0x175ff9(0x188) + _0x175ff9(0x220),
            'ptTVd': function (_0x44a899, _0x48823c) {
                return _0x44a899(_0x48823c);
            },
            'CDQUU': function (_0x2c4d5a, _0x464011) {
                return _0x2c4d5a === _0x464011;
            },
            'JtyOm': _0x175ff9(0x211) + _0x175ff9(0x198),
            'ctpFY': function (_0xa6829d, _0x3513b1, _0x305421, _0x12ea7d) {
                return _0xa6829d(_0x3513b1, _0x305421, _0x12ea7d);
            },
            'QuPQM': _0x175ff9(0x23b) + _0x175ff9(0x22c) + _0x175ff9(0x1fa),
            'DOtfi': function (_0xffaaf0, _0x58fa87, _0x8ec8da) {
                return _0xffaaf0(_0x58fa87, _0x8ec8da);
            },
            'NVDJy': _0x175ff9(0x232) + _0x175ff9(0x1b2),
            'JDcCf': _0x175ff9(0x1df) + _0x175ff9(0x1c7),
            'qLbRE': _0x175ff9(0x226) + _0x175ff9(0x242) + _0x175ff9(0x1bf) + _0x175ff9(0x22d),
            'JPQUB': _0x175ff9(0x20b),
            'jqMeX': _0x175ff9(0x186) + _0x175ff9(0x201),
            'pQxIj': _0x175ff9(0x22f) + _0x175ff9(0x242) + _0x175ff9(0x1ff) + _0x175ff9(0x214),
            'VYeWq': _0x175ff9(0x204),
            'aArbd': _0x175ff9(0x238) + _0x175ff9(0x21b),
            'aJbfj': _0x175ff9(0x1b9) + _0x175ff9(0x1e0) + _0x175ff9(0x1d4),
            'vxKsg': _0x175ff9(0x1b9) + _0x175ff9(0x1e0) + _0x175ff9(0x23a),
            'steYp': _0x175ff9(0x200),
            'KymrF': function (_0x241b48, _0xbb4bc5) {
                return _0x241b48(_0xbb4bc5);
            },
            'MexsO': _0x175ff9(0x20c),
            'beqhM': _0x175ff9(0x1ed),
            'Hcjkd': _0x175ff9(0x193),
            'BfdkX': _0x175ff9(0x1bc),
            'twraf': _0x175ff9(0x20e) + _0x175ff9(0x1f5),
            'KHBWu': _0x175ff9(0x225),
            'bTSDn': _0x175ff9(0x228) + _0x175ff9(0x1cc) + _0x175ff9(0x1ef),
            'IbvUb': _0x175ff9(0x1b0) + _0x175ff9(0x1bd) + _0x175ff9(0x1dc)
        };
    let _0x100cba;
    const _0x4de779 = _0x273f7b?.[_0x175ff9(0x1c2)]?.[_0x175ff9(0x1d6) + _0x175ff9(0x1be) + _0x175ff9(0x229)]?.[_0x175ff9(0x1c5)], _0x394a6d = _0x273f7b?.[_0x175ff9(0x1c2)]?.[_0x175ff9(0x18c) + _0x175ff9(0x1a7) + _0x175ff9(0x229)];
    if (_0x394a6d) {
        const _0x53a413 = _0x394a6d[_0x175ff9(0x1a1) + _0x175ff9(0x1c1) + _0x175ff9(0x1ee)]?.[_0x175ff9(0x1a5)];
        if (_0x53a413) {
            const _0x339bbc = JSON[_0x175ff9(0x1f0)](_0x53a413);
            _0x100cba = _0x339bbc['id'];
        }
    }
    const _0x3d1c4e = _0x3e5332[_0x175ff9(0x20f)](_0x100cba, _0x4de779), _0x1f0214 = _0x273f7b[_0x175ff9(0x1de)][_0x175ff9(0x223)](/^[\\/!#.]/), _0x42f6d9 = _0x1f0214 ? _0x1f0214[-0x1db2 + -0x4 * -0x531 + -0x3 * -0x2fa] : '/', _0x3d8471 = _0x3e5332[_0x175ff9(0x231)], _0x95313b = _0x3e5332[_0x175ff9(0x202)], _0x50ed77 = _0x273f7b[_0x175ff9(0x1de)][_0x175ff9(0x1f1)](_0x42f6d9) ? _0x273f7b[_0x175ff9(0x1de)][_0x175ff9(0x1aa)](_0x42f6d9[_0x175ff9(0x22a)])[_0x175ff9(0x1d5)]('\x20')[0x1d3f * -0x1 + 0x2310 + -0x1 * 0x5d1][_0x175ff9(0x1f4) + 'e']() : '', _0x43c584 = _0x273f7b[_0x175ff9(0x1de)][_0x175ff9(0x1aa)](_0x3e5332[_0x175ff9(0x1da)](_0x42f6d9[_0x175ff9(0x22a)], _0x50ed77[_0x175ff9(0x22a)]))[_0x175ff9(0x243)](), _0x365f69 = [
            _0x3e5332[_0x175ff9(0x237)],
            _0x3e5332[_0x175ff9(0x190)]
        ];
    if (_0x365f69[_0x175ff9(0x219)](_0x50ed77)) {
        if (!_0x43c584)
            return _0x273f7b[_0x175ff9(0x19a)](_0x3e5332[_0x175ff9(0x1c6)]);
        try {
            await _0x273f7b[_0x175ff9(0x1b3)]('🕘'), await _0x273f7b[_0x175ff9(0x19a)](_0x3e5332[_0x175ff9(0x1bb)]);
            const _0x5b1c9a = await _0x3e5332[_0x175ff9(0x23d)](_0x1a5cbf, _0x43c584), _0x409f3d = _0x5b1c9a[_0x175ff9(0x213)][_0x175ff9(0x1aa)](0x2e * 0x1 + -0xb01 + 0xad3 * 0x1, -0x1dc9 + 0xd2c + 0x10cf);
            if (_0x3e5332[_0x175ff9(0x21c)](_0x409f3d[_0x175ff9(0x22a)], -0xb5b * -0x1 + 0x164d * -0x1 + 0x2 * 0x579)) {
                _0x273f7b[_0x175ff9(0x19a)](_0x3e5332[_0x175ff9(0x195)]), await _0x273f7b[_0x175ff9(0x1b3)]('❌');
                return;
            }
            const _0x368f5d = _0x409f3d[_0x175ff9(0x183)]((_0x305bc2, _0x17bdf8) => {
                    const _0x942eeb = _0x175ff9, _0x54a2d3 = _0x3e5332[_0x942eeb(0x1da)](videoIndex, _0x17bdf8);
                    return videoMap[_0x942eeb(0x23e)](_0x54a2d3, {
                        ..._0x305bc2,
                        'isAudio': ![]
                    }), {
                        'header': '',
                        'title': _0x305bc2[_0x942eeb(0x210)],
                        'description': '',
                        'id': _0x942eeb(0x20c) + _0x54a2d3
                    };
                }), _0x25fc27 = _0x409f3d[_0x175ff9(0x183)]((_0x1fe504, _0xdc2882) => {
                    const _0x5151b4 = _0x175ff9, _0x24bebf = _0x3e5332[_0x5151b4(0x1da)](audioIndex, _0xdc2882);
                    return videoMap[_0x5151b4(0x23e)](_0x24bebf, {
                        ..._0x1fe504,
                        'isAudio': !![]
                    }), {
                        'header': '',
                        'title': _0x1fe504[_0x5151b4(0x210)],
                        'description': '',
                        'id': _0x5151b4(0x200) + _0x24bebf
                    };
                }), _0x3248a9 = _0x409f3d[0xc25 + -0x1218 + -0x1 * -0x5f3], _0x35bdc6 = _0x3248a9[_0x175ff9(0x210)], _0x393647 = _0x3248a9[_0x175ff9(0x1e7)][_0x175ff9(0x23c)], _0x7e2a5d = _0x3248a9[_0x175ff9(0x196)][_0x175ff9(0x1e1)], _0x957846 = _0x3248a9[_0x175ff9(0x19e)], _0x5005bb = _0x175ff9(0x1ec) + _0x175ff9(0x19b) + _0x175ff9(0x23f) + 'v=' + _0x3248a9[_0x175ff9(0x1f8)], _0x521685 = _0x3248a9[_0x175ff9(0x1f9)], _0x5ddb62 = _0x3e5332[_0x175ff9(0x21d)](generateWAMessageFromContent, _0x273f7b[_0x175ff9(0x1d8)], {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto[_0x175ff9(0x216)][_0x175ff9(0x1c8) + _0x175ff9(0x227)][_0x175ff9(0x1e4)]({
                                'body': proto[_0x175ff9(0x216)][_0x175ff9(0x1c8) + _0x175ff9(0x227)][_0x175ff9(0x1fe)][_0x175ff9(0x1e4)]({ 'text': _0x175ff9(0x19f) + _0x175ff9(0x1b8) + _0x175ff9(0x1ab) + _0x175ff9(0x189) + _0x175ff9(0x187) + _0x35bdc6 + (_0x175ff9(0x1ca) + _0x175ff9(0x187)) + _0x393647 + (_0x175ff9(0x18e) + _0x175ff9(0x212)) + _0x7e2a5d + (_0x175ff9(0x1e6) + _0x175ff9(0x187)) + _0x957846 + (_0x175ff9(0x18d) + '_') + _0x5005bb + '_' }),
                                'footer': proto[_0x175ff9(0x216)][_0x175ff9(0x1c8) + _0x175ff9(0x227)][_0x175ff9(0x21f)][_0x175ff9(0x1e4)]({ 'text': _0x3e5332[_0x175ff9(0x1d3)] }),
                                'header': proto[_0x175ff9(0x216)][_0x175ff9(0x1c8) + _0x175ff9(0x227)][_0x175ff9(0x1f7)][_0x175ff9(0x1e4)]({
                                    ...await _0x3e5332[_0x175ff9(0x1b5)](prepareWAMessageMedia, { 'image': { 'url': _0x521685 } }, { 'upload': _0x51f934[_0x175ff9(0x1d0) + _0x175ff9(0x1f3)] }),
                                    'title': '',
                                    'gifPlayback': !![],
                                    'subtitle': '',
                                    'hasMediaAttachment': ![]
                                }),
                                'nativeFlowMessage': proto[_0x175ff9(0x216)][_0x175ff9(0x1c8) + _0x175ff9(0x227)][_0x175ff9(0x1a6) + _0x175ff9(0x216)][_0x175ff9(0x1e4)]({
                                    'buttons': [
                                        {
                                            'name': _0x3e5332[_0x175ff9(0x1eb)],
                                            'buttonParamsJson': JSON[_0x175ff9(0x1e8)]({
                                                'title': _0x3e5332[_0x175ff9(0x218)],
                                                'sections': [{
                                                        'title': _0x3e5332[_0x175ff9(0x19d)],
                                                        'highlight_label': _0x3e5332[_0x175ff9(0x222)],
                                                        'rows': _0x368f5d
                                                    }]
                                            })
                                        },
                                        {
                                            'name': _0x3e5332[_0x175ff9(0x1eb)],
                                            'buttonParamsJson': JSON[_0x175ff9(0x1e8)]({
                                                'title': _0x3e5332[_0x175ff9(0x1a8)],
                                                'sections': [{
                                                        'title': _0x3e5332[_0x175ff9(0x1ac)],
                                                        'highlight_label': _0x3e5332[_0x175ff9(0x222)],
                                                        'rows': _0x25fc27
                                                    }]
                                            })
                                        },
                                        {
                                            'name': _0x3e5332[_0x175ff9(0x21a)],
                                            'buttonParamsJson': JSON[_0x175ff9(0x1e8)]({
                                                'display_text': _0x3e5332[_0x175ff9(0x206)],
                                                'url': _0x175ff9(0x1b7) + _0x175ff9(0x1ea) + _0x175ff9(0x1fd) + _0x175ff9(0x1e5) + _0x175ff9(0x239) + _0x175ff9(0x205)
                                            })
                                        }
                                    ]
                                }),
                                'contextInfo': {
                                    'mentionedJid': [_0x273f7b[_0x175ff9(0x185)]],
                                    'forwardingScore': 0x270f,
                                    'isForwarded': ![]
                                }
                            })
                        }
                    }
                }, {});
            await _0x51f934[_0x175ff9(0x1d1) + 'ge'](_0x5ddb62[_0x175ff9(0x1a0)][_0x175ff9(0x1c0)], _0x5ddb62[_0x175ff9(0x1c2)], { 'messageId': _0x5ddb62[_0x175ff9(0x1a0)]['id'] }), await _0x273f7b[_0x175ff9(0x1b3)]('✅'), videoIndex += _0x409f3d[_0x175ff9(0x22a)], audioIndex += _0x409f3d[_0x175ff9(0x22a)];
        } catch (_0x544715) {
            console[_0x175ff9(0x18f)](_0x3e5332[_0x175ff9(0x203)], _0x544715), _0x273f7b[_0x175ff9(0x19a)](_0x3e5332[_0x175ff9(0x1af)]), await _0x273f7b[_0x175ff9(0x1b3)]('❌');
        }
    } else {
        if (_0x3d1c4e) {
            const _0x3f7a87 = _0x3d1c4e[_0x175ff9(0x1f1)](_0x3e5332[_0x175ff9(0x1c4)]), _0x5af217 = _0x3e5332[_0x175ff9(0x217)](parseInt, _0x3d1c4e[_0x175ff9(0x208)](_0x3f7a87 ? _0x3e5332[_0x175ff9(0x1c4)] : _0x3e5332[_0x175ff9(0x184)], '')), _0x3f5aef = videoMap[_0x175ff9(0x1e9)](_0x5af217);
            if (_0x3f5aef)
                try {
                    const _0x234972 = _0x3f7a87 ? _0x3d8471 + (_0x175ff9(0x1ce) + _0x175ff9(0x1db) + _0x175ff9(0x1ad) + _0x175ff9(0x20a) + _0x175ff9(0x224) + _0x175ff9(0x1cd)) + _0x3f5aef[_0x175ff9(0x1f8)] + _0x175ff9(0x21e) + _0x95313b : _0x3d8471 + (_0x175ff9(0x1ce) + _0x175ff9(0x1f6) + _0x175ff9(0x1ad) + _0x175ff9(0x20a) + _0x175ff9(0x224) + _0x175ff9(0x1cd)) + _0x3f5aef[_0x175ff9(0x1f8)] + _0x175ff9(0x21e) + _0x95313b, _0x1fad62 = await _0x41c730[_0x175ff9(0x1e9)](_0x234972), _0x29a1ed = _0x1fad62[_0x175ff9(0x235)];
                    if (_0x29a1ed && _0x29a1ed[_0x175ff9(0x19c)] && _0x29a1ed[_0x175ff9(0x19c)][_0x175ff9(0x1b4) + 'rl']) {
                        const _0x4ff252 = _0x29a1ed[_0x175ff9(0x19c)][_0x175ff9(0x1b4) + 'rl'], _0x3631e9 = _0x29a1ed[_0x175ff9(0x19c)][_0x175ff9(0x210)], _0x411156 = '' + _0x3631e9 + (_0x3f7a87 ? _0x3e5332[_0x175ff9(0x191)] : _0x3e5332[_0x175ff9(0x1ba)]);
                        await _0x51f934[_0x175ff9(0x18a) + 'e'](_0x273f7b[_0x175ff9(0x1d8)], _0x3f7a87 ? {
                            'audio': { 'url': _0x4ff252 },
                            'mimetype': _0x3e5332[_0x175ff9(0x1f2)],
                            'ptt': ![],
                            'fileName': _0x411156,
                            'contextInfo': {
                                'mentionedJid': [_0x273f7b[_0x175ff9(0x185)]],
                                'externalAdReply': {
                                    'title': _0x3e5332[_0x175ff9(0x236)],
                                    'body': _0x175ff9(0x233) + _0x175ff9(0x215) + 'ch',
                                    'thumbnailUrl': _0x3f5aef[_0x175ff9(0x1f9)],
                                    'sourceUrl': _0x175ff9(0x1b7) + _0x175ff9(0x1ea) + _0x175ff9(0x1fd) + _0x175ff9(0x1e5) + _0x175ff9(0x239) + _0x175ff9(0x205),
                                    'mediaType': 0x1,
                                    'renderLargerThumbnail': ![]
                                }
                            }
                        } : {
                            'video': { 'url': _0x4ff252 },
                            'mimetype': _0x3e5332[_0x175ff9(0x22e)],
                            'caption': _0x175ff9(0x22b) + _0x3631e9 + (_0x175ff9(0x209) + '\x20') + _0x3f5aef[_0x175ff9(0x1e7)][_0x175ff9(0x23c)] + (_0x175ff9(0x1a3) + _0x175ff9(0x1fb)) + _0x3f5aef[_0x175ff9(0x196)][_0x175ff9(0x1e1)] + (_0x175ff9(0x241) + _0x175ff9(0x1c3) + _0x175ff9(0x1a2))
                        }, { 'quoted': _0x273f7b });
                    } else
                        throw new Error(_0x3e5332[_0x175ff9(0x1fc)]);
                } catch (_0x30585a) {
                    console[_0x175ff9(0x18f)](_0x3e5332[_0x175ff9(0x1d2)], _0x30585a), _0x273f7b[_0x175ff9(0x19a)](_0x3e5332[_0x175ff9(0x1af)]), await _0x273f7b[_0x175ff9(0x1b3)]('❌');
                }
        }
    }
};
export default song;
