(function (_0x782fa6, _0xe2db54) {
    const _0xb5630d = _0x98f0, _0x55246c = _0x782fa6();
    while (!![]) {
        try {
            const _0x354bf2 = -parseInt(_0xb5630d(0x145)) / 0x1 * (parseInt(_0xb5630d(0x163)) / 0x2) + -parseInt(_0xb5630d(0x153)) / 0x3 + -parseInt(_0xb5630d(0x172)) / 0x4 + parseInt(_0xb5630d(0x144)) / 0x5 + -parseInt(_0xb5630d(0x147)) / 0x6 * (parseInt(_0xb5630d(0x15f)) / 0x7) + -parseInt(_0xb5630d(0x16c)) / 0x8 + parseInt(_0xb5630d(0x186)) / 0x9;
            if (_0x354bf2 === _0xe2db54)
                break;
            else
                _0x55246c['push'](_0x55246c['shift']());
        } catch (_0x3ed838) {
            _0x55246c['push'](_0x55246c['shift']());
        }
    }
}(_0x5267, 0xb7e27));
import _0x3d148c, { prepareWAMessageMedia } from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = _0x3d148c;
import _0x4d271d from 'nayan-media-downloader';
const {tikdown} = _0x4d271d, searchResultsMap = new Map();
function _0x5267() {
    const _0x3113b2 = [
        'media_audio2_',
        '3904048ulnoUA',
        '_*\x0aPlease\x20provide\x20a\x20TikTok\x20URL.',
        '🎦\x20ᴠɪᴅᴇᴏ',
        'reply',
        'video/mp4',
        'message',
        '1936864tZfwei',
        'from',
        'arrayBuffer',
        'media_audio_',
        'get',
        'audio2',
        'Error\x20processing\x20your\x20request:',
        'create',
        'tiktok',
        'length',
        'media_video_',
        'selectedId',
        'nickname',
        'split',
        '𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐓𝐈𝐊𝐓𝐎𝐊\x20𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑\x0a\x0a*ᴛɪᴛᴛʟᴇ:*\x20',
        'Header',
        '🎵\x20ᴀᴜᴅɪᴏ\x20ᴅᴏᴄᴜᴍᴇɴᴛ',
        'media_video2_',
        'pushName',
        'parse',
        '20817990bRMumm',
        'paramsJson',
        '*Hello\x20_',
        'body',
        'toLowerCase',
        '6753005jiiwcv',
        '607755qRusvs',
        'Tiktok.mp4',
        '414EAXFtw',
        'slice',
        'Footer',
        'author',
        'media_',
        '🎵\x20ᴀᴜᴅɪᴏ',
        'audio/mpeg',
        'templateButtonReplyMessage',
        'quick_reply',
        'title',
        'nativeFlowResponseMessage',
        'React',
        '10605MhweyE',
        'error',
        'data',
        'includes',
        'NativeFlowMessage',
        'view',
        'match',
        'Message',
        'stringify',
        'waUploadToServer',
        'key',
        'duration',
        '134624nPLrAY',
        'trim',
        'startsWith',
        'No\x20results\x20found.',
        '2TadecU',
        'InteractiveMessage',
        'video2',
        'ttdl',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        'Body',
        'audio',
        'video'
    ];
    _0x5267 = function () {
        return _0x3113b2;
    };
    return _0x5267();
}
let searchIndex = 0x1;
function _0x98f0(_0x1389cb, _0x357706) {
    const _0x526757 = _0x5267();
    return _0x98f0 = function (_0x98f0ef, _0x576196) {
        _0x98f0ef = _0x98f0ef - 0x142;
        let _0x4e0a47 = _0x526757[_0x98f0ef];
        return _0x4e0a47;
    }, _0x98f0(_0x1389cb, _0x357706);
}
const tiktokCommand = async (_0x237fe8, _0x62f281) => {
        const _0x404bbe = _0x98f0;
        let _0x274f94;
        const _0x119720 = _0x237fe8?.[_0x404bbe(0x171)]?.[_0x404bbe(0x14e)]?.[_0x404bbe(0x17d)], _0x5ed6aa = _0x237fe8?.[_0x404bbe(0x171)]?.['interactiveResponseMessage'];
        if (_0x5ed6aa) {
            const _0xfb6e5d = _0x5ed6aa[_0x404bbe(0x151)]?.[_0x404bbe(0x187)];
            if (_0xfb6e5d) {
                const _0x4b0bf5 = JSON[_0x404bbe(0x185)](_0xfb6e5d);
                _0x274f94 = _0x4b0bf5['id'];
            }
        }
        const _0xbfb8cf = _0x274f94 || _0x119720, _0x3173e0 = _0x237fe8['body'][_0x404bbe(0x159)](/^[\\/!#.]/), _0x1e6d4e = _0x3173e0 ? _0x3173e0[0x0] : '/', _0x2ab253 = _0x237fe8[_0x404bbe(0x142)][_0x404bbe(0x161)](_0x1e6d4e) ? _0x237fe8[_0x404bbe(0x142)][_0x404bbe(0x148)](_0x1e6d4e['length'])[_0x404bbe(0x17f)]('\x20')[0x0][_0x404bbe(0x143)]() : '', _0x36e078 = _0x237fe8[_0x404bbe(0x142)][_0x404bbe(0x148)](_0x1e6d4e[_0x404bbe(0x17b)] + _0x2ab253[_0x404bbe(0x17b)])[_0x404bbe(0x160)](), _0x47bddf = [
                _0x404bbe(0x17a),
                'tt',
                _0x404bbe(0x166)
            ];
        if (_0x47bddf[_0x404bbe(0x156)](_0x2ab253)) {
            if (!_0x36e078)
                return _0x237fe8[_0x404bbe(0x16f)](_0x404bbe(0x188) + _0x237fe8[_0x404bbe(0x184)] + _0x404bbe(0x16d));
            try {
                await _0x237fe8[_0x404bbe(0x152)]('🕘');
                const _0x131ef8 = await tikdown(_0x36e078);
                if (!_0x131ef8['status']) {
                    await _0x237fe8[_0x404bbe(0x16f)](_0x404bbe(0x162)), await _0x237fe8[_0x404bbe(0x152)]('❌');
                    return;
                }
                searchResultsMap['set'](searchIndex, _0x131ef8);
                const _0x4d8981 = searchResultsMap[_0x404bbe(0x176)](searchIndex), _0xd86d60 = [
                        {
                            'name': 'quick_reply',
                            'buttonParamsJson': JSON['stringify']({
                                'display_text': _0x404bbe(0x16e),
                                'id': _0x404bbe(0x17c) + searchIndex
                            })
                        },
                        {
                            'name': _0x404bbe(0x14f),
                            'buttonParamsJson': JSON['stringify']({
                                'display_text': _0x404bbe(0x14c),
                                'id': _0x404bbe(0x175) + searchIndex
                            })
                        },
                        {
                            'name': _0x404bbe(0x14f),
                            'buttonParamsJson': JSON['stringify']({
                                'display_text': '🎦\x20ᴠɪᴅᴇᴏ\x20ᴅᴏᴄᴜᴍᴇɴᴛ',
                                'id': _0x404bbe(0x183) + searchIndex
                            })
                        },
                        {
                            'name': 'quick_reply',
                            'buttonParamsJson': JSON[_0x404bbe(0x15b)]({
                                'display_text': _0x404bbe(0x182),
                                'id': _0x404bbe(0x16b) + searchIndex
                            })
                        }
                    ], _0x307427 = generateWAMessageFromContent(_0x237fe8[_0x404bbe(0x173)], {
                        'viewOnceMessage': {
                            'message': {
                                'messageContextInfo': {
                                    'deviceListMetadata': {},
                                    'deviceListMetadataVersion': 0x2
                                },
                                'interactiveMessage': proto[_0x404bbe(0x15a)][_0x404bbe(0x164)]['create']({
                                    'body': proto[_0x404bbe(0x15a)][_0x404bbe(0x164)][_0x404bbe(0x168)][_0x404bbe(0x179)]({ 'text': _0x404bbe(0x180) + _0x4d8981[_0x404bbe(0x155)][_0x404bbe(0x150)] + '\x0a*ᴀᴜᴛʜᴏʀ:*\x20' + _0x4d8981['data'][_0x404bbe(0x14a)][_0x404bbe(0x17e)] + '\x0a*ᴠɪᴇᴡs:*\x20' + _0x4d8981[_0x404bbe(0x155)][_0x404bbe(0x158)] + '\x0a*ᴅᴜʀᴀᴛɪᴏɴ:*\x20' + _0x4d8981[_0x404bbe(0x155)][_0x404bbe(0x15e)] + 's\x0aUser:\x20*_' + _0x237fe8['pushName'] + '_*\x0a' }),
                                    'footer': proto[_0x404bbe(0x15a)][_0x404bbe(0x164)][_0x404bbe(0x149)][_0x404bbe(0x179)]({ 'text': _0x404bbe(0x167) }),
                                    'header': proto['Message'][_0x404bbe(0x164)][_0x404bbe(0x181)][_0x404bbe(0x179)]({
                                        ...await prepareWAMessageMedia({ 'image': { 'url': 'https://telegra.ph/file/bf3a4cac5fc11b3199b56.jpg' } }, { 'upload': _0x62f281[_0x404bbe(0x15c)] }),
                                        'title': '',
                                        'gifPlayback': !![],
                                        'subtitle': '',
                                        'hasMediaAttachment': ![]
                                    }),
                                    'nativeFlowMessage': proto[_0x404bbe(0x15a)]['InteractiveMessage'][_0x404bbe(0x157)]['create']({ 'buttons': _0xd86d60 }),
                                    'contextInfo': {
                                        'mentionedJid': [_0x237fe8['sender']],
                                        'forwardingScore': 0x270f,
                                        'isForwarded': ![]
                                    }
                                })
                            }
                        }
                    }, {});
                await _0x62f281['relayMessage'](_0x307427['key']['remoteJid'], _0x307427['message'], { 'messageId': _0x307427[_0x404bbe(0x15d)]['id'] }), await _0x237fe8[_0x404bbe(0x152)]('✅'), searchIndex += 0x1;
            } catch (_0x28a7c7) {
                console['error']('Error\x20processing\x20your\x20request:', _0x28a7c7), await _0x237fe8[_0x404bbe(0x16f)]('Error\x20processing\x20your\x20request.'), await _0x237fe8[_0x404bbe(0x152)]('❌');
            }
        } else {
            if (_0xbfb8cf) {
                if (_0xbfb8cf['startsWith'](_0x404bbe(0x14b))) {
                    const _0xca6fe9 = _0xbfb8cf[_0x404bbe(0x17f)]('_'), _0x3d72e4 = _0xca6fe9[0x1], _0x21b2d5 = parseInt(_0xca6fe9[0x2]), _0x468b92 = searchResultsMap['get'](_0x21b2d5);
                    if (_0x468b92)
                        try {
                            const _0x16a9ab = _0x468b92[_0x404bbe(0x155)][_0x404bbe(0x16a)], _0x20e9ec = _0x468b92[_0x404bbe(0x155)][_0x404bbe(0x169)];
                            let _0x205b7a, _0x2b18d5, _0x5c6964;
                            if (_0x3d72e4 === _0x404bbe(0x16a))
                                _0x205b7a = await getStreamBuffer(_0x16a9ab), _0x2b18d5 = _0x404bbe(0x170);
                            else {
                                if (_0x3d72e4 === 'audio')
                                    _0x205b7a = await getStreamBuffer(_0x20e9ec), _0x2b18d5 = _0x404bbe(0x14d);
                                else {
                                    if (_0x3d72e4 === _0x404bbe(0x165))
                                        _0x205b7a = await getStreamBuffer(_0x16a9ab), _0x2b18d5 = _0x404bbe(0x170);
                                    else
                                        _0x3d72e4 === _0x404bbe(0x177) && (_0x205b7a = await getStreamBuffer(_0x20e9ec), _0x2b18d5 = _0x404bbe(0x14d));
                                }
                            }
                            const _0x686521 = _0x205b7a[_0x404bbe(0x17b)] / (0x400 * 0x400);
                            if (_0x3d72e4 === _0x404bbe(0x16a) && _0x686521 <= 0x12c)
                                _0x5c6964 = {
                                    'video': _0x205b7a,
                                    'mimetype': _0x404bbe(0x170),
                                    'caption': _0x404bbe(0x167)
                                };
                            else {
                                if (_0x3d72e4 === _0x404bbe(0x169) && _0x686521 <= 0x12c)
                                    _0x5c6964 = {
                                        'audio': _0x205b7a,
                                        'mimetype': _0x404bbe(0x14d),
                                        'caption': '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*'
                                    };
                                else {
                                    if (_0x3d72e4 === 'video2' && _0x686521 <= 0x12c)
                                        _0x5c6964 = {
                                            'document': _0x205b7a,
                                            'mimetype': 'video/mp4',
                                            'fileName': _0x404bbe(0x146),
                                            'caption': _0x404bbe(0x167)
                                        };
                                    else
                                        _0x3d72e4 === 'audio2' && _0x686521 <= 0x12c && (_0x5c6964 = {
                                            'document': _0x205b7a,
                                            'mimetype': _0x404bbe(0x14d),
                                            'fileName': 'Tiktok.mp3',
                                            'caption': '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*'
                                        });
                                }
                            }
                            await _0x62f281['sendMessage'](_0x237fe8['from'], _0x5c6964, { 'quoted': _0x237fe8 });
                        } catch (_0x22b69a) {
                            console[_0x404bbe(0x154)](_0x404bbe(0x178), _0x22b69a), await _0x237fe8['reply']('Error\x20processing\x20your\x20request.'), await _0x237fe8[_0x404bbe(0x152)]('❌');
                        }
                }
            }
        }
    }, getStreamBuffer = async _0xaa89f9 => {
        const _0x1390bc = _0x98f0, _0x1eed90 = await fetch(_0xaa89f9), _0x5f35c3 = await _0x1eed90[_0x1390bc(0x174)]();
        return Buffer['from'](_0x5f35c3);
    };
export default tiktokCommand;
