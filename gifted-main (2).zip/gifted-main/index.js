const _0x160682 = _0x4bd0;
(function (_0x219627, _0x3e193b) {
    const _0x1f8586 = _0x4bd0, _0x3c252b = _0x219627();
    while (!![]) {
        try {
            const _0x25a197 = -parseInt(_0x1f8586(0x20a)) / 0x1 + -parseInt(_0x1f8586(0x1d8)) / 0x2 + -parseInt(_0x1f8586(0x1f6)) / 0x3 * (-parseInt(_0x1f8586(0x206)) / 0x4) + parseInt(_0x1f8586(0x1cc)) / 0x5 * (-parseInt(_0x1f8586(0x1f9)) / 0x6) + -parseInt(_0x1f8586(0x1fe)) / 0x7 * (-parseInt(_0x1f8586(0x1e6)) / 0x8) + -parseInt(_0x1f8586(0x1c6)) / 0x9 + parseInt(_0x1f8586(0x1fa)) / 0xa;
            if (_0x25a197 === _0x3e193b)
                break;
            else
                _0x3c252b['push'](_0x3c252b['shift']());
        } catch (_0xd9eb44) {
            _0x3c252b['push'](_0x3c252b['shift']());
        }
    }
}(_0x3d3e, 0xa6926));
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta[_0x160682(0x1ff)]), __dirname = _0x361761[_0x160682(0x1d4)](__filename);
function _0x3d3e() {
    const _0x1a2968 = [
        'bold',
        ',\x22time\x22:\x22',
        'string',
        'listMessage',
        'fatal',
        'writeFileSync',
        'Error\x20during\x20auto\x20reaction:',
        'darwin',
        'private',
        'random',
        'messages.upsert',
        'PORT',
        '2354706ATzBTm',
        'CHECKING\x20WA\x20VERSION\x20v',
        'exit',
        'timedOut',
        'session',
        'Linux',
        '5NcgLHs',
        'public',
        'platform',
        'connectionClosed',
        'text',
        'silent',
        ',\x20isLatest:\x20',
        'temp/gifted.html',
        'dirname',
        'get',
        'buttonsMessage',
        'Gifted~',
        '1444640qJWlZq',
        'close',
        'win32',
        'statusCode',
        'creds',
        'SESSION_ID',
        'connection.update',
        '♻️\x20Connection\x20reestablished\x20after\x20restart.',
        'open',
        'output',
        'Windows',
        'registered',
        'child',
        '#32CD32',
        '8TNNdzC',
        'listen',
        'blue',
        'messages',
        '[🤕]\x20Connection\x20Lost\x20from\x20Server,\x20reconnecting.',
        'error',
        './session/creds.json',
        'MacOS',
        'Session\x20ID\x20Converted\x20to\x20creds.json',
        'keys',
        'level',
        'sendMessage',
        '[😩]\x20Connection\x20closed,\x20reconnecting.',
        'connectionLost',
        'fromMe',
        'length',
        '58002SQdzSw',
        'Creds.json\x20file\x20saved\x20in\x20Session\x20Folder',
        'red',
        '36642RylNgh',
        '10541130zJeyYB',
        'MODE',
        'GIFTED\x20CONNECTING\x20TO\x20WHATSAPP',
        'loadMessage',
        '9236164MERtqv',
        'url',
        'user',
        'hex',
        '121.0.6167.159',
        'message',
        'log',
        'group-participants.update',
        '4FVbpEZ',
        '[😭]\x20Device\x20Logged\x20Out,\x20Please\x20Delete\x20Session\x20and\x20Link\x20Again.',
        'remoteJid',
        'join',
        '720560Vwllwl',
        'sendFile',
        '✅WHATSAPP\x20LOGIN\x20SUCCESSFUL,\x20𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐕𝟓\x20𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃!'
    ];
    _0x3d3e = function () {
        return _0x1a2968;
    };
    return _0x3d3e();
}
import _0x5c4b9f from 'dotenv';
_0x5c4b9f['config']();
import {
    makeWASocket,
    Browsers,
    jidDecode,
    makeInMemoryStore,
    makeCacheableSignalKeyStore,
    fetchLatestBaileysVersion,
    DisconnectReason,
    useMultiFileAuthState,
    getAggregateVotesInPollMessage
} from 'gifted-baileys';
import {
    Handler,
    Callupdate,
    GroupUpdate
} from './gifted/funcs/giftedte.js';
import { Boom } from '@hapi/boom';
import _0x377ea0 from 'express';
import _0x3c266f from 'pino';
import _0x4e2f4e from 'fs';
import _0x485a64 from 'node-cache';
function _0x4bd0(_0x3cd412, _0x5258fb) {
    const _0x3d3ec5 = _0x3d3e();
    return _0x4bd0 = function (_0x4bd0b0, _0x2b240e) {
        _0x4bd0b0 = _0x4bd0b0 - 0x1c0;
        let _0x8b56e4 = _0x3d3ec5[_0x4bd0b0];
        return _0x8b56e4;
    }, _0x4bd0(_0x3cd412, _0x5258fb);
}
import _0x361761 from 'path';
import _0x3c4653 from 'chalk';
import { writeFile } from 'fs/promises';
import _0xb6102d from 'moment-timezone';
import _0x2445a5 from 'axios';
import _0x57a49c from 'node-fetch';
import * as _0x392e29 from 'os';
import _0x4a168e from './set.cjs';
import _0x1bf598 from './gift/giftke.cjs';
const {emojis, doReact} = _0x1bf598, sessionName = _0x160682(0x1ca), app = _0x377ea0(), orange = _0x3c4653[_0x160682(0x20d)][_0x160682(0x201)]('#FFA500'), lime = _0x3c4653['bold'][_0x160682(0x201)](_0x160682(0x1e5));
let useQR, isSessionPutted, initialConnection = !![];
const PORT = process['env'][_0x160682(0x1c5)] || 0x1388, MAIN_LOGGER = _0x3c266f({ 'timestamp': () => _0x160682(0x20e) + new Date()['toJSON']() + '\x22' }), logger = MAIN_LOGGER[_0x160682(0x1e4)]({});
logger[_0x160682(0x1f0)] = 'trace';
const msgRetryCounterCache = new _0x485a64(), store = makeInMemoryStore({
        'logger': _0x3c266f()[_0x160682(0x1e4)]({
            'level': _0x160682(0x1d1),
            'stream': 'store'
        })
    });
async function start() {
    const _0x1fc9aa = _0x160682;
    !_0x4a168e['SESSION_ID'] ? (useQR = ![], isSessionPutted = ![]) : (useQR = ![], isSessionPutted = !![]);
    let {
            state: _0x1bfc7b,
            saveCreds: _0x3c96dd
        } = await useMultiFileAuthState(sessionName), {
            version: _0x2d8283,
            isLatest: _0x5f31a7
        } = await fetchLatestBaileysVersion();
    console[_0x1fc9aa(0x204)](_0x3c4653[_0x1fc9aa(0x1f8)](_0x1fc9aa(0x1fc))), console[_0x1fc9aa(0x204)](_0x3c4653['green'](_0x1fc9aa(0x1c7) + _0x2d8283[_0x1fc9aa(0x209)]('.') + _0x1fc9aa(0x1d2) + _0x5f31a7));
    const _0x37c4e4 = _0x392e29['platform']() === _0x1fc9aa(0x1da) ? _0x1fc9aa(0x1e2) : _0x392e29[_0x1fc9aa(0x1ce)]() === _0x1fc9aa(0x1c1) ? _0x1fc9aa(0x1ed) : _0x1fc9aa(0x1cb), _0x1f9672 = makeWASocket({
            'version': _0x2d8283,
            'logger': _0x3c266f({ 'level': 'silent' }),
            'printQRInTerminal': useQR,
            'browser': [
                _0x37c4e4,
                'chrome',
                _0x1fc9aa(0x202)
            ],
            'patchMessageBeforeSending': _0x105234 => {
                const _0x2d6734 = _0x1fc9aa, _0x15712c = !!(_0x105234[_0x2d6734(0x1d6)] || _0x105234['templateMessage'] || _0x105234[_0x2d6734(0x210)]);
                return _0x15712c && (_0x105234 = {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadataVersion': 0x2,
                                'deviceListMetadata': {}
                            },
                            ..._0x105234
                        }
                    }
                }), _0x105234;
            },
            'auth': {
                'creds': _0x1bfc7b[_0x1fc9aa(0x1dc)],
                'keys': makeCacheableSignalKeyStore(_0x1bfc7b[_0x1fc9aa(0x1ef)], _0x3c266f({ 'level': 'fatal' })[_0x1fc9aa(0x1e4)]({ 'level': _0x1fc9aa(0x211) }))
            },
            'getMessage': async _0x8db526 => {
                const _0x4df92e = _0x1fc9aa;
                if (store) {
                    const _0x308dba = await store[_0x4df92e(0x1fd)](_0x8db526[_0x4df92e(0x208)], _0x8db526['id']);
                    return _0x308dba[_0x4df92e(0x203)] || undefined;
                }
                return { 'conversation': _0x4df92e(0x20c) };
            },
            'markOnlineOnConnect': !![],
            'generateHighQualityLinkPreview': !![],
            'defaultQueryTimeoutMs': undefined,
            'msgRetryCounterCache': msgRetryCounterCache
        });
    store?.['bind'](_0x1f9672['ev']);
    if (!_0x1f9672['authState'][_0x1fc9aa(0x1dc)][_0x1fc9aa(0x1e3)] && isSessionPutted) {
        const _0x51f729 = _0x4a168e[_0x1fc9aa(0x1dd)]['split'](_0x1fc9aa(0x1d7))[0x1], _0x427c11 = 'https://pastebin.com/raw/' + _0x51f729, _0x251136 = await _0x57a49c(_0x427c11), _0x1a7a69 = await _0x251136[_0x1fc9aa(0x1d0)]();
        typeof _0x1a7a69 === _0x1fc9aa(0x20f) && (_0x4e2f4e[_0x1fc9aa(0x212)](_0x1fc9aa(0x1ec), _0x1a7a69), console[_0x1fc9aa(0x204)](_0x1fc9aa(0x1ee)), console[_0x1fc9aa(0x204)](_0x1fc9aa(0x1f7)), await start());
    }
    async function _0x1a8a94(_0x1270a7) {
        const _0xfff1cd = _0x1fc9aa;
        if (store) {
            const _0x4ba2a3 = await store[_0xfff1cd(0x1fd)](_0x1270a7[_0xfff1cd(0x208)], _0x1270a7['id']);
            return _0x4ba2a3?.[_0xfff1cd(0x203)];
        }
        return { 'conversation': _0xfff1cd(0x20c) };
    }
    _0x1f9672['ev']['on'](_0x1fc9aa(0x1c4), async _0x36ad92 => await Handler(_0x36ad92, _0x1f9672, logger)), _0x1f9672['ev']['on']('call', async _0x499e9e => await Callupdate(_0x499e9e, _0x1f9672)), _0x1f9672['ev']['on'](_0x1fc9aa(0x205), async _0x54e94d => await GroupUpdate(_0x1f9672, _0x54e94d));
    if (_0x4a168e[_0x1fc9aa(0x1fb)] === _0x1fc9aa(0x1cd))
        _0x1f9672[_0x1fc9aa(0x1cd)] = !![];
    else
        _0x4a168e['MODE'] === _0x1fc9aa(0x1c2) && (_0x1f9672[_0x1fc9aa(0x1cd)] = ![]);
    _0x1f9672['ev']['on'](_0x1fc9aa(0x1de), async _0x277682 => {
        const _0x2f2793 = _0x1fc9aa, {
                connection: _0x12154f,
                lastDisconnect: _0x1169e2
            } = _0x277682;
        if (_0x12154f === _0x2f2793(0x1d9)) {
            let _0x24a794 = new Boom(_0x1169e2?.['error'])?.[_0x2f2793(0x1e1)][_0x2f2793(0x1db)];
            if (_0x24a794 === DisconnectReason[_0x2f2793(0x1cf)])
                console[_0x2f2793(0x204)](_0x3c4653[_0x2f2793(0x1f8)](_0x2f2793(0x1f2))), start();
            else {
                if (_0x24a794 === DisconnectReason[_0x2f2793(0x1f3)])
                    console[_0x2f2793(0x204)](_0x3c4653[_0x2f2793(0x1f8)](_0x2f2793(0x1ea))), start();
                else {
                    if (_0x24a794 === DisconnectReason['loggedOut'])
                        console[_0x2f2793(0x204)](_0x3c4653['red'](_0x2f2793(0x207))), process[_0x2f2793(0x1c8)]();
                    else {
                        if (_0x24a794 === DisconnectReason['restartRequired'])
                            console[_0x2f2793(0x204)](_0x3c4653[_0x2f2793(0x1e8)]('[♻️]\x20Server\x20Restarting.')), start();
                        else
                            _0x24a794 === DisconnectReason[_0x2f2793(0x1c9)] && (console[_0x2f2793(0x204)](_0x3c4653[_0x2f2793(0x1f8)]('[⏳]\x20Connection\x20Timed\x20Out,\x20Trying\x20to\x20Reconnect.')), start());
                    }
                }
            }
        }
        _0x12154f === _0x2f2793(0x1e0) && (initialConnection ? (console[_0x2f2793(0x204)](_0x3c4653['green']('✅WHATSAPP\x20LOGIN\x20SUCCESSFUL,\x20𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐕𝟓\x20𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃')), _0x1f9672[_0x2f2793(0x1f1)](_0x1f9672[_0x2f2793(0x200)]['id'], { 'text': '𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐕𝟓\x20𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃\x0a\x0a𝐃𝐚𝐭𝐚𝐛𝐚𝐬𝐞\x20\x20:\x20Cpanel\x20\x0a𝐏𝐥𝐚𝐭𝐟𝐨𝐫𝐦:\x20Whatsapp\x20\x0a𝐎𝐰𝐧𝐞𝐫\x20\x20\x20\x20:\x20t.me/mouricedevs\x0a𝐓𝐮𝐭𝐨𝐫𝐢𝐚𝐥𝐬\x20\x20:\x20youtube.com/@giftedtechnexus\x0a𝐖𝐚𝐂𝐡𝐚𝐧𝐧𝐞𝐥\x20:\x20https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l\x0a\x0a>\x20𝐏𝐎𝐖𝐄𝐑𝐄𝐃\x20𝐁𝐘\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐓𝐄𝐂𝐇' }), initialConnection = ![]) : console[_0x2f2793(0x204)](_0x3c4653['blue'](_0x2f2793(0x1df))));
    }), _0x1f9672['ev']['on'](_0x1fc9aa(0x1c4), async _0xf4c3bc => {
        const _0x3fd3de = _0x1fc9aa;
        try {
            const _0x1dbac8 = _0xf4c3bc[_0x3fd3de(0x1e9)][0x0];
            if (!_0x1dbac8['key'][_0x3fd3de(0x1f4)] && _0x4a168e['AUTO_REACT']) {
                console[_0x3fd3de(0x204)](_0x1dbac8);
                if (_0x1dbac8[_0x3fd3de(0x203)]) {
                    const _0x33d057 = emojis[Math['floor'](Math[_0x3fd3de(0x1c3)]() * emojis[_0x3fd3de(0x1f5)])];
                    await doReact(_0x33d057, _0x1dbac8, _0x1f9672);
                }
            }
        } catch (_0x5318e4) {
            console[_0x3fd3de(0x1eb)](_0x3fd3de(0x1c0), _0x5318e4);
        }
    });
}
start(), app[_0x160682(0x1d5)]('/', (_0x4fa0b3, _0x4e48df) => {
    const _0x3916ac = _0x160682;
    _0x4e48df[_0x3916ac(0x20b)](_0x361761[_0x3916ac(0x209)](__dirname, _0x3916ac(0x1d3)));
}), app[_0x160682(0x1e7)](PORT, () => {
    console['log']('Gifted\x20Server\x20Live\x20on\x20Port\x20' + PORT);
});
